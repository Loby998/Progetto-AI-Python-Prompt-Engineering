# =============================================================
#  MainBeeAI.py  —  BeeAI "Cyberpunk Hive" Interface
#  v2.0 — honeycomb su tutto lo sfondo, % progress, console gialla
# =============================================================

from Models.BeeAI import *
from Models.colors import *
from Models.HoneycombCanvas import *
import customtkinter as ctk

# ── PALETTE ─────────────────────────────────────────────────
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")


# ── ENTRY POINT ──────────────────────────────────────────────

if __name__ == "__main__":
    app = BeeAIApp()
    app.mainloop()
