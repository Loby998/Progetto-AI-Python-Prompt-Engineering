# =============================================================
#  validatore_risposte.py  —  Backend BeeAI
#  5 iterazioni indipendenti + prompt evolutivo + output terminale
#  v2.0 — valutazione rigorosa + penalità duplicati + fallback prompt
# =============================================================

import json
import re
import requests
from difflib import SequenceMatcher

# ── CONFIGURAZIONE ───────────────────────────────────────────
URL          = "http://192.168.49.231:11434/api/chat"
MODELLO      = "gpt-oss:20b"
N_ITERAZIONI = 5

# Soglia similarità per considerare due risposte "duplicate" (0.85 = 85%)
SOGLIA_DUPLICATO = 0.82

DOMANDA_FALLBACK = (
    "Di cosa parla principalmente questo testo? "
    "Fornisci un riassunto sintetico dei punti chiave."
)

SYSTEM_RISPOSTA = (
    "Sei un assistente esperto. Rispondi alla domanda usando SOLO "
    "le informazioni presenti nel testo fornito. "
    "Se la risposta non è nel testo, scrivi esattamente: 'Informazione non presente nel testo'. "
    "Sii sintetico e diretto. Non inventare informazioni non presenti nel testo."
)

SYSTEM_FALLBACK_CHECK = (
    "Valuta se la seguente stringa è una domanda comprensibile e sensata in italiano o inglese. "
    "Rispondi SOLO con 'SI' se è comprensibile, oppure 'NO' se è incomprensibile, "
    "priva di senso, troppo corta, o non è una domanda. Nessuna parola in più."
)

SYSTEM_GIUDICE = """Sei un giudice severo e imparziale. Valuta la risposta da 1 a 10 seguendo RIGOROSAMENTE questi criteri:

CRITERI DI VALUTAZIONE (applica tutti):

1. FEDELTÀ AL TESTO (peso principale):
   - La risposta contiene SOLO informazioni presenti nel testo? 
   - Se ci sono affermazioni inventate o non verificabili nel testo: punteggio MASSIMO 3.
   - Se dice "Informazione non presente" quando la risposta è nel testo: punteggio MASSIMO 2.

2. RISPOSTA ALLA DOMANDA:
   - La risposta risponde effettivamente alla domanda posta?
   - Se è completamente off-topic: punteggio MASSIMO 2.
   - Se risponde parzialmente: max 6.

3. COMPLETEZZA:
   - Copre tutti gli aspetti richiesti dalla domanda? 
   - Risposta troppo vaga o generica: punteggio MASSIMO 5.

4. QUALITÀ:
   - È chiara, ben strutturata e precisa?

SCALA OBBLIGATORIA:
- 9-10: Risposta eccellente, perfettamente fedele al testo, completa e precisa
- 7-8: Risposta buona, quasi tutto corretto
- 5-6: Risposta parziale o con lievi imprecisioni
- 3-4: Risposta con errori significativi o informazioni dubbie
- 1-2: Risposta sbagliata, inventata o completamente fuori tema

IMPORTANTE: Sii RIGOROSO. Un punteggio di 9-10 va dato SOLO a risposte veramente eccellenti.
Rispondi SOLO con il numero intero da 1 a 10. Nessuna parola in più."""


# ── CHIAMATE AL MODELLO ──────────────────────────────────────

def chiama_modello_stream(system_prompt, messaggio, on_token=None):
    """Streaming: chiama on_token(token) per ogni pezzo di testo ricevuto."""
    payload = {
        "model": MODELLO,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user",   "content": messaggio},
        ],
        "stream": True
    }
    risposta_completa = ""
    try:
        with requests.post(URL, json=payload, stream=True, timeout=120) as r:
            r.raise_for_status()
            for riga in r.iter_lines():
                if riga:
                    chunk = json.loads(riga.decode("utf-8"))
                    token = chunk.get("message", {}).get("content", "")
                    risposta_completa += token
                    if on_token:
                        on_token(token)
                    if chunk.get("done", False):
                        break
        return risposta_completa.strip()
    except Exception as e:
        print(f"Errore connessione: {e}")
        return None


def chiama_modello(system_prompt, messaggio):
    """Chiamata semplice senza streaming."""
    payload = {
        "model": MODELLO,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user",   "content": messaggio},
        ],
        "stream": False
    }
    try:
        r = requests.post(URL, json=payload, timeout=120)
        r.raise_for_status()
        return r.json()["message"]["content"].strip()
    except Exception as e:
        print(f"Errore connessione: {e}")
        return None


# ── VERIFICA COMPRENSIBILITÀ DOMANDA ────────────────────────

def verifica_domanda(domanda):
    """
    Controlla se la domanda è comprensibile.
    Restituisce (domanda_usata, era_fallback).
    """
    # Check rapido: troppo corta o solo simboli
    pulita = domanda.strip()
    if len(pulita) < 8 or not any(c.isalpha() for c in pulita):
        return DOMANDA_FALLBACK, True

    risultato = chiama_modello(SYSTEM_FALLBACK_CHECK, f"Domanda: {pulita}")
    if risultato and "SI" in risultato.upper():
        return pulita, False
    else:
        return DOMANDA_FALLBACK, True


# ── SIMILARITÀ TRA RISPOSTE ──────────────────────────────────

def similarita(r1, r2):
    """Restituisce un valore 0-1 di similarità tra due stringhe."""
    return SequenceMatcher(None, r1.lower().strip(), r2.lower().strip()).ratio()


def calcola_penalita_duplicato(risposta_nuova, risposte_precedenti):
    """
    Se la risposta è molto simile a una già generata, restituisce una penalità (0-4 punti).
    """
    if not risposte_precedenti:
        return 0, 0.0

    max_sim = max(similarita(risposta_nuova, r) for r in risposte_precedenti)

    if max_sim >= SOGLIA_DUPLICATO:
        return 4, max_sim   # penalità forte: risposta quasi identica
    elif max_sim >= 0.65:
        return 2, max_sim   # penalità media: risposta molto simile
    elif max_sim >= 0.50:
        return 1, max_sim   # penalità lieve: risposta simile
    return 0, max_sim


# ── GENERAZIONE E VALUTAZIONE ────────────────────────────────

def genera_risposta(testo, domanda, prompt_extra="", on_token=None):
    """Genera una risposta con eventuale contesto evolutivo."""
    messaggio = f"TESTO:\n{testo}\n\nDOMANDA:\n{domanda}"
    if prompt_extra:
        messaggio += f"\n\n{prompt_extra}"
    return chiama_modello_stream(SYSTEM_RISPOSTA, messaggio, on_token)


def valuta_risposta(testo, domanda, risposta, risposte_precedenti=None):
    """
    Assegna un punteggio da 1 a 10 con sistema di valutazione rigoroso.
    Applica penalità per risposte duplicate.
    """
    if risposte_precedenti is None:
        risposte_precedenti = []

    # ── Punteggio base dal giudice ──
    messaggio = (
        f"TESTO ORIGINALE:\n{testo}\n\n"
        f"DOMANDA:\n{domanda}\n\n"
        f"RISPOSTA DA VALUTARE:\n{risposta}\n\n"
        f"Valuta la risposta da 1 a 10 seguendo i criteri forniti."
    )
    risultato = chiama_modello(SYSTEM_GIUDICE, messaggio)

    punteggio_base = 5  # default se parsing fallisce
    if risultato:
        # Estrai il numero dalla risposta
        numeri = re.findall(r'\b(10|[1-9])\b', risultato)
        if numeri:
            punteggio_base = int(numeri[0])
        punteggio_base = max(1, min(10, punteggio_base))

    # ── Penalità duplicato ──
    penalita, max_sim = calcola_penalita_duplicato(risposta, risposte_precedenti)

    punteggio_finale = max(1, punteggio_base - penalita)

    return punteggio_finale, punteggio_base, penalita, max_sim


# ── CICLO PRINCIPALE: 5 ITERAZIONI INDIPENDENTI ──────────────

def genera_e_valuta(testo, domanda, on_token=None, on_done=None, on_log=None):
    """
    Esegue 5 iterazioni indipendenti di generazione + valutazione rigorosa.
    Include verifica domanda, prompt evolutivo e penalità duplicati.
    """

    def log(msg):
        print(msg)
        if on_log:
            on_log(msg)

    # ── Verifica comprensibilità domanda ──────────────────────
    domanda_usata, era_fallback = verifica_domanda(domanda)

    risultati     = []   # lista di (risposta, punteggio_finale)
    solo_risposte = []   # lista di sole stringhe per il calcolo similarità

    # ── Intestazione terminale ──
    log("=" * 58)
    log(f"  BeeAI — Validatore v2.0  |  {N_ITERAZIONI} iterazioni")
    log("=" * 58)
    if era_fallback:
        log(f"  ⚠  Domanda non comprensibile — uso domanda di default")
        log(f"  DOMANDA (fallback): {domanda_usata}")
    else:
        log(f"  DOMANDA: {domanda_usata}")
    log("=" * 58)

    # Notifica GUI se domanda fallback
    if era_fallback and on_log:
        log(f"\n⚠  ATTENZIONE: La domanda inserita non era comprensibile.")
        log(f"   Domanda usata: \"{domanda_usata}\"\n")

    for i in range(N_ITERAZIONI):
        log(f"\n[{i+1}/{N_ITERAZIONI}] Generazione risposta...")

        # ── Prompt evolutivo ──────────────────────────────────
        prompt_extra = ""
        if risultati:
            punteggi_prec   = [r[1] for r in risultati]
            migliore_finora = max(risultati, key=lambda x: x[1])
            prompt_extra = (
                f"CONTESTO ITERAZIONI PRECEDENTI:\n"
                f"Sono già state generate {len(risultati)} risposte "
                f"con punteggi: {punteggi_prec}.\n"
                f"La risposta migliore finora ha punteggio {migliore_finora[1]}/10:\n"
                f"\"{migliore_finora[0][:200]}...\"\n"
                f"IMPORTANTE: Produci una risposta DIVERSA e più precisa. "
                f"Non ripetere le stesse frasi già usate."
            )

        # ── Genera risposta (streaming → card GUI) ────────────
        risposta = genera_risposta(
            testo, domanda_usata,
            prompt_extra=prompt_extra,
            on_token=lambda token, idx=i: on_token(idx, token) if on_token else None
        )

        if risposta is None:
            risposta          = "Errore di connessione."
            punteggio_finale  = 0
            punteggio_base    = 0
            penalita          = 0
            max_sim           = 0.0
        else:
            log(f"[{i+1}/{N_ITERAZIONI}] Valutazione in corso...")
            punteggio_finale, punteggio_base, penalita, max_sim = valuta_risposta(
                testo, domanda_usata, risposta, solo_risposte
            )

        risultati.append((risposta, punteggio_finale))
        solo_risposte.append(risposta)

        # ── Log risposta e punteggio ──────────────────────────
        log(f"\n  Risposta {i+1}:")
        log(f"  {risposta[:300]}{'...' if len(risposta) > 300 else ''}")
        log(f"  Punteggio grezzo: {punteggio_base}/10")
        if penalita > 0:
            log(f"  ⚠  Penalità duplicato: -{penalita} (similarità: {max_sim:.0%})")
        log(f"  Punteggio finale: {punteggio_finale}/10")
        log("-" * 58)

        if on_done:
            on_done(i, risposta, punteggio_finale, penalita > 0)

    # ── Risultato finale ──────────────────────────────────────
    migliore_idx                      = max(range(N_ITERAZIONI), key=lambda i: risultati[i][1])
    migliore_risposta, migliore_score = risultati[migliore_idx]

    log(f"\n{'='*58}")
    log(f"  MIGLIORE RISPOSTA — iterazione {migliore_idx+1}"
        f" — punteggio {migliore_score}/10")
    log(f"{'='*58}")
    log(f"  {migliore_risposta}")
    log(f"{'='*58}\n")

    return risultati
