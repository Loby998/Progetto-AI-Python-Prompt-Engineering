import json
import requests

OLLAMA_URL = "http://192.168.49.231:11434/api/chat"  # cambia IP
MODEL_NAME = "gpt-oss:20b"  # cambia modello se vuoi


def chat():
    messages = []

    print("Chat con Ollama. Scrivi 'esci' per terminare.\n")

    while True:
        user_input = input("Tu: ").strip()
        if user_input.lower() in {"esci", "exit", "quit"}:
            print("Chiusura chat.")
            break

        messages.append({"role": "user", "content": user_input})

        payload = {
            "model": MODEL_NAME,
            "messages": messages,
            "stream": False
        }

        try:
            response = requests.post(OLLAMA_URL, json=payload, timeout=120)
            response.raise_for_status()
            data = response.json()

            assistant_message = data["message"]["content"]
            print(f"\nAI: {assistant_message}\n")

            messages.append({"role": "assistant", "content": assistant_message})

        except requests.RequestException as e:
            print(f"Errore di connessione/API: {e}\n")
        except (KeyError, json.JSONDecodeError) as e:
            print(f"Errore nel parsing della risposta: {e}\n")


if __name__ == "__main__":
    chat()