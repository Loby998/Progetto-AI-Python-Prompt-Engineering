import json
import requests

OLLAMA_URL = "http://192.168.49.231:11434/api/chat"
MODEL_NAME = "gpt-oss:20b"


def chat():
    messages = []

    print("Chat con Ollama (streaming). Scrivi 'esci' per terminare.\n")

    while True:
        user_input = input("Tu: ").strip()
        if user_input.lower() in {"esci", "exit", "quit"}:
            print("Chiusura chat.")
            break

        messages.append({"role": "user", "content": user_input})

        payload = {
            "model": MODEL_NAME,
            "messages": messages,
            "think": "low",
            "stream": True
        }

        try:
            with requests.post(OLLAMA_URL, json=payload, stream=True, timeout=120) as response:
                response.raise_for_status()

                print("\nAI: ", end="", flush=True)

                full_response = ""

                for line in response.iter_lines():
                    if line:
                        chunk = json.loads(line.decode("utf-8"))

                        content = chunk.get("message", {}).get("content", "")
                        print(content, end="", flush=True)

                        full_response += content

                        # Fine risposta
                        if chunk.get("done", False):
                            break

                print("\n")

                messages.append({"role": "assistant", "content": full_response})

        except requests.RequestException as e:
            print(f"Errore di connessione/API: {e}\n")
        except (KeyError, json.JSONDecodeError) as e:
            print(f"Errore nel parsing della risposta: {e}\n")


if __name__ == "__main__":
    chat()