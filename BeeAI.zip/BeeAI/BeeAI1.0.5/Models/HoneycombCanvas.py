from Models.colors import Colors
import tkinter as tk
import math

color: Colors = Colors()


class HoneycombCanvas(tk.Canvas):
    """Canvas che disegna un pattern honeycomb su tutto il suo sfondo."""

    def __init__(self, parent, size=28, colore=color.GIALLO_HEX, alpha_fill="#111100", **kwargs):
        super().__init__(parent, highlightthickness=0, **kwargs)
        self._size       = size
        self._colore     = colore
        self._alpha_fill = alpha_fill
        self.bind("<Configure>", self._on_resize)

    def _on_resize(self, event=None):
        """Ridisegna quando il canvas cambia dimensione."""
        self.after_idle(self._disegna)

    def _disegna(self):
        """Disegna le celle esagonali a tappeto sul canvas."""
        self.delete("all")
        w = self.winfo_width()
        h = self.winfo_height()
        if w < 2 or h < 2:
            return

        size     = self._size
        h_hex    = math.sqrt(3) * size   # altezza di un esagono
        w_hex    = 2 * size              # larghezza di un esagono
        offset_y = h_hex / 2             # sfasamento verticale per le colonne dispari

        col = 0
        x   = size
        while x < w + w_hex:
            y = 0 if col % 2 == 0 else offset_y
            while y < h + h_hex:
                # Calcola i 6 vertici dell'esagono
                punti = []
                for i in range(6):
                    angolo = math.radians(60 * i + 30)
                    punti += [x + size * math.cos(angolo),
                               y + size * math.sin(angolo)]
                self.create_polygon(punti, outline=self._colore,
                                    fill=self._alpha_fill, width=1)
                y += h_hex
            x   += w_hex * 0.75   # le colonne si sovrappongono per il 25%
            col += 1
