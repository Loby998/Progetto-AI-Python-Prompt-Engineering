import tkinter as tk
import customtkinter as ctk
import threading
import time
from Models.colors import Colors
from Models.HoneycombCanvas import HoneycombCanvas as hcc
from validatore_risposteBeeAI import genera_e_valuta, MODELLO, N_ITERAZIONI

color: Colors = Colors()


def _lbl_sezione(parent, testo):
    """Etichetta di sezione gialla."""
    ctk.CTkLabel(parent, text=testo, font=("Consolas", 11, "bold"),
                 text_color=color.GIALLO).pack(anchor="w", padx=18, pady=(14, 4))


def _textbox(parent, height):
    """Casella di testo scura con bordo."""
    t = ctk.CTkTextbox(parent, height=height, corner_radius=8,
                       fg_color=color.NERO_INPUT, border_color=color.BORDO,
                       border_width=1, text_color="#CCCCCC", font=("Consolas", 12))
    t.pack(fill="x", padx=14, pady=(0, 6))
    return t


class BeeAIApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("BeeAI — Validatore Intelligente")
        self.geometry("1380x900")
        self.minsize(1050, 700)
        self.configure(fg_color=color.NERO)

        self.cards       = {}
        self._completate = 0
        self._costruisci_ui()

    # ── COSTRUZIONE UI ───────────────────────────────────────

    def _costruisci_ui(self):

        # Sfondo honeycomb su tutta la finestra
        self._bg_canvas = hcc(
            self, size=26,
            colore=color.GIALLO_HEX,
            alpha_fill="#0D0C00",
            bg=color.NERO
        )
        self._bg_canvas.place(x=0, y=0, relwidth=1, relheight=1)

        # Header
        self.header = tk.Frame(self, bg="#090909", height=78)
        self.header.place(x=0, y=0, relwidth=1)
        self.header.pack_propagate(False)

        # Honeycomb sull'header
        self._hc_header = hcc(
            self.header, size=20,
            colore=color.GIALLO,
            alpha_fill="#0A0800",
            bg="#0A0800"
        )
        self._hc_header.place(x=0, y=0, relwidth=1, relheight=1)

        tk.Label(self.header, text="🐝",      font=("Segoe UI", 28),    bg="#0A0800", fg=color.GIALLO    ).place(x=25, y=16)
        tk.Label(self.header, text="BeeAI",   font=("Consolas", 26, "bold"), bg="#0A0800", fg=color.GIALLO).place(x=70, y=16)
        tk.Label(self.header, text="Validatore Intelligente", font=("Consolas", 11), bg="#0A0800", fg=color.GIALLO_DIM).place(x=74, y=53)
        tk.Label(self.header, text=f"⚡  {MODELLO}", font=("Consolas", 10), bg="#0A0800", fg=color.GIALLO_DIM).place(relx=0.985, y=28, anchor="ne")

        # Linea separatrice sotto header
        tk.Frame(self, bg=color.GIALLO, height=2).place(x=0, y=78, relwidth=1)

        # Corpo principale
        corpo = tk.Frame(self, bg=color.NERO, highlightthickness=0)
        corpo.place(x=0, y=82, relwidth=1, relheight=1, height=-82)

        main = tk.Frame(corpo, bg=color.NERO)
        main.pack(fill="both", expand=True, padx=18, pady=14)

        # ── PANNELLO SINISTRO (input) ────────────────────────
        sx_outer = tk.Frame(main, bg=color.NERO_CARD,
                            highlightbackground=color.BORDO,
                            highlightthickness=1, bd=0)
        sx_outer.pack(side="left", fill="y", ipadx=2, ipady=2)

        sx = ctk.CTkFrame(sx_outer, fg_color=color.NERO_CARD, corner_radius=10, width=310)
        sx.pack(fill="both", expand=True)
        sx.pack_propagate(False)

        _lbl_sezione(sx, "📄  TESTO DI RIFERIMENTO")
        self.txt_testo = _textbox(sx, height=200)

        _lbl_sezione(sx, "❓  DOMANDA")
        self.txt_domanda = _textbox(sx, height=80)

        # Badge numero iterazioni (fisso)
        badge = ctk.CTkFrame(sx, fg_color="#1A1A00", corner_radius=6,
                             border_width=1, border_color=color.BORDO)
        badge.pack(fill="x", padx=16, pady=(0, 12))
        ctk.CTkLabel(badge, text="Iterazioni:", text_color=color.GRIGIO,
                     font=("Consolas", 11)).pack(side="left", padx=10, pady=6)
        ctk.CTkLabel(badge, text=f"{N_ITERAZIONI}  (fisso)", text_color=color.GIALLO,
                     font=("Consolas", 11, "bold")).pack(side="right", padx=10)

        self.btn_avvia = ctk.CTkButton(
            sx, text="▶  AVVIA ANALISI",
            font=("Consolas", 14, "bold"),
            fg_color=color.GIALLO, text_color=color.NERO,
            hover_color=color.GIALLO_GLOW,
            height=46, corner_radius=8, command=self._avvia
        )
        self.btn_avvia.pack(fill="x", padx=16, pady=(0, 8))

        self.btn_reset = ctk.CTkButton(
            sx, text="↺  Reset",
            fg_color="transparent", border_width=1, border_color=color.BORDO,
            text_color=color.GRIGIO, hover_color="#1A1800",
            font=("Consolas", 11), command=self._reset
        )
        self.btn_reset.pack(fill="x", padx=16)

        ctk.CTkFrame(sx, height=1, fg_color=color.BORDO).pack(fill="x", padx=16, pady=10)

        self.lbl_stato = ctk.CTkLabel(sx, text="In attesa...",
                                      text_color="#555", font=("Consolas", 11))
        self.lbl_stato.pack(anchor="w", padx=18)

        # Barra di avanzamento con percentuale
        prog_frame = ctk.CTkFrame(sx, fg_color="transparent")
        prog_frame.pack(fill="x", padx=16, pady=(6, 2))

        self.progressbar = ctk.CTkProgressBar(
            prog_frame, progress_color=color.GIALLO,
            fg_color=color.NERO_INPUT, height=8, corner_radius=4
        )
        self.progressbar.pack(fill="x")
        self.progressbar.set(0)

        self.lbl_perc = ctk.CTkLabel(sx, text="0%",
                                     text_color=color.GIALLO_DIM,
                                     font=("Consolas", 11, "bold"))
        self.lbl_perc.pack(anchor="e", padx=18)

        # Separatore verticale tra pannello sx e area dx
        tk.Frame(main, bg=color.BORDO, width=1).pack(side="left", fill="y", padx=10)

        # ── AREA DESTRA (cards risultati + console) ──────────
        area_dx = tk.Frame(main, bg=color.NERO)
        area_dx.pack(side="left", fill="both", expand=True)

        # Pannello scrollabile con le card dei risultati
        self.pannello_dx = ctk.CTkScrollableFrame(
            area_dx, fg_color="transparent",
            scrollbar_button_color=color.BORDO
        )
        self.pannello_dx.pack(fill="both", expand=True)
        self._mostra_placeholder()

        # Console di output
        tk.Frame(area_dx, bg=color.BORDO, height=1).pack(fill="x", pady=(6, 0))

        console_header = tk.Frame(area_dx, bg=color.NERO)
        console_header.pack(fill="x", pady=(3, 2))
        tk.Label(console_header, text="◉  CONSOLE OUTPUT",
                 font=("Consolas", 10, "bold"),
                 bg=color.NERO, fg=color.CONSOLE_FG).pack(side="left", padx=4)
        tk.Label(console_header, text="stdout",
                 font=("Consolas", 9),
                 bg=color.NERO, fg="#333").pack(side="right", padx=4)

        self.console = ctk.CTkTextbox(
            area_dx, height=155,
            fg_color="#0A0800",
            text_color=color.CONSOLE_FG,
            font=("Consolas", 11), corner_radius=6,
            border_width=1, border_color=color.GIALLO_DIM,
            wrap="none"
        )
        self.console.pack(fill="x")
        self.console.insert("1.0", "BeeAI console pronta. Avvia un'analisi per vedere l'output...\n")
        self.console.configure(state="disabled")

    # ── PLACEHOLDER ──────────────────────────────────────────

    def _mostra_placeholder(self):
        """Svuota il pannello dx e mostra il messaggio iniziale."""
        for w in self.pannello_dx.winfo_children():
            w.destroy()
        ctk.CTkLabel(
            self.pannello_dx,
            text="🐝  I risultati appariranno qui...",
            text_color="#2A2800", font=("Consolas", 15)
        ).pack(pady=100)

    # ── AVVIA ANALISI ────────────────────────────────────────

    def _avvia(self):
        testo   = self.txt_testo.get("1.0", "end-1c").strip()
        domanda = self.txt_domanda.get("1.0", "end-1c").strip()

        if not testo:
            self.lbl_stato.configure(text="⚠  Inserisci il testo.", text_color=color.ROSSO)
            return
        if not domanda:
            self.lbl_stato.configure(text="⚠  Inserisci la domanda.", text_color=color.ROSSO)
            return

        self.btn_avvia.configure(state="disabled", text="⏳  Elaborazione...")
        self.cards       = {}
        self._completate = 0
        self.progressbar.set(0)
        self.lbl_perc.configure(text="0%")
        self.lbl_stato.configure(text="🐝  Le api stanno lavorando...", text_color=color.GIALLO)

        self.console.configure(state="normal")
        self.console.delete("1.0", "end")
        self.console.configure(state="disabled")

        # Crea N card vuote nell'area risultati
        for w in self.pannello_dx.winfo_children():
            w.destroy()
        for i in range(N_ITERAZIONI):
            self.cards[i] = self._crea_card(i + 1)

        threading.Thread(
            target=self._thread_lavoro,
            args=(testo, domanda),
            daemon=True
        ).start()

    # ── THREAD DI LAVORO (gira in background) ────────────────

    def _thread_lavoro(self, testo, domanda):
        inizio = time.time()

        def on_token(idx, token):
            """Aggiorna la card con il token ricevuto in streaming."""
            widgets = self.cards.get(idx)
            if not widgets:
                return
            def _upd():
                t = widgets["txt"]
                t.configure(state="normal")
                if t.get("1.0", "end-1c") == "⏳  Generazione in corso...":
                    t.delete("1.0", "end")
                t.insert("end", token)
                t.configure(state="disabled")
                t.see("end")
            self.after(0, _upd)

        def on_done(idx, risposta, punteggio, era_duplicato=False):
            """Aggiorna il punteggio e la progressbar al termine di ogni iterazione."""
            self._completate += 1
            perc   = self._completate / N_ITERAZIONI
            colore = color.VERDE if punteggio >= 7 else (color.GIALLO if punteggio >= 4 else color.ROSSO)
            def _upd():
                w = self.cards[idx]
                testo_score = f"{punteggio}/10" + (" ⚠" if era_duplicato else "")
                w["score"].configure(text=testo_score, text_color=colore)
                self.progressbar.set(perc)
                self.lbl_perc.configure(text=f"{int(perc * 100)}%")
                self.lbl_stato.configure(
                    text=f"🐝  {self._completate}/{N_ITERAZIONI} complete",
                    text_color=color.GIALLO
                )
            self.after(0, _upd)

        def on_log(msg):
            """Stampa nella console GUI."""
            def _upd():
                self.console.configure(state="normal")
                self.console.insert("end", msg + "\n")
                self.console.configure(state="disabled")
                self.console.see("end")
            self.after(0, _upd)

        genera_e_valuta(testo, domanda,
                        on_token=on_token,
                        on_done=on_done,
                        on_log=on_log)

        self.after(0, lambda: self._fine(time.time() - inizio))

    # ── FINE ANALISI ─────────────────────────────────────────

    def _fine(self, durata):
        """Chiamata al termine di tutte le iterazioni."""
        self.btn_avvia.configure(state="normal", text="▶  AVVIA ANALISI")
        self.lbl_stato.configure(text=f"✅  Completato in {durata:.1f}s", text_color=color.VERDE)
        self.progressbar.set(1)
        self.lbl_perc.configure(text="100%")

        # Trova e mette in evidenza la card con punteggio più alto
        migliore_idx, migliore_score = -1, -1
        for idx, w in self.cards.items():
            try:
                s = int(w["score"].cget("text").replace("/10", "").replace("⚠", "").strip())
                if s > migliore_score:
                    migliore_score, migliore_idx = s, idx
            except (ValueError, AttributeError):
                pass

        if migliore_idx >= 0:
            w = self.cards[migliore_idx]
            w["card"].configure(border_color=color.GIALLO, border_width=2)
            w["label"].configure(text="⭐  MIGLIORE RISPOSTA", text_color=color.GIALLO_GLOW)
            figli = list(self.pannello_dx.winfo_children())
            if figli:
                w["card"].pack_forget()
                w["card"].pack(fill="x", pady=(0, 12), padx=4, before=figli[0])

    # ── CREA CARD ────────────────────────────────────────────

    def _crea_card(self, numero):
        """Crea e restituisce una card per visualizzare un risultato."""
        card = ctk.CTkFrame(self.pannello_dx, fg_color=color.NERO_CARD,
                            border_width=1, border_color=color.BORDO, corner_radius=10)
        card.pack(fill="x", pady=(0, 10), padx=4)

        # Barra laterale colorata
        ctk.CTkFrame(card, width=3, fg_color=color.GIALLO_DIM, corner_radius=3).pack(
            side="left", fill="y", padx=(8, 0), pady=8
        )

        contenuto = ctk.CTkFrame(card, fg_color="transparent")
        contenuto.pack(side="left", fill="both", expand=True)

        header = ctk.CTkFrame(contenuto, fg_color="transparent")
        header.pack(fill="x", padx=12, pady=(8, 4))

        lbl_titolo = ctk.CTkLabel(header, text=f"◈  Risposta {numero}",
                                  font=("Consolas", 12, "bold"), text_color=color.GRIGIO)
        lbl_titolo.pack(side="left")

        lbl_score = ctk.CTkLabel(header, text="—/10",
                                 font=("Consolas", 16, "bold"), text_color="#333")
        lbl_score.pack(side="right")

        ctk.CTkLabel(header, text="⬡", font=("Segoe UI", 14),
                     text_color=color.GIALLO_DIM).pack(side="right", padx=6)

        txt = ctk.CTkTextbox(contenuto, height=80, fg_color="transparent",
                             text_color="#CCCCCC", wrap="word", font=("Consolas", 12))
        txt.pack(fill="x", padx=10, pady=(0, 8))
        txt.insert("1.0", "⏳  Generazione in corso...")
        txt.configure(state="disabled")

        return {"card": card, "txt": txt, "score": lbl_score, "label": lbl_titolo}

    # ── RESET ────────────────────────────────────────────────

    def _reset(self):
        """Pulisce tutti i campi e riporta l'app allo stato iniziale."""
        self.txt_testo.delete("1.0", "end")
        self.txt_domanda.delete("1.0", "end")
        self.progressbar.set(0)
        self.lbl_perc.configure(text="0%")
        self.lbl_stato.configure(text="In attesa...", text_color="#555")
        self.cards = {}
        self._mostra_placeholder()
        self.console.configure(state="normal")
        self.console.delete("1.0", "end")
        self.console.insert("1.0", "Console pulita. Pronto per una nuova analisi.\n")
        self.console.configure(state="disabled")
