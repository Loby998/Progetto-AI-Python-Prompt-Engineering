class Colors:
    """Palette colori dell'interfaccia BeeAI."""
    def __init__(self) -> None:
        self.NERO        = "#0A0A0A"   # sfondo principale
        self.NERO_CARD   = "#101010"   # sfondo card
        self.NERO_INPUT  = "#181818"   # sfondo input
        self.GIALLO      = "#D4A017"   # giallo principale
        self.GIALLO_DIM  = "#8B6914"   # giallo attenuato
        self.GIALLO_GLOW = "#E8B520"   # giallo luminoso (hover/highlight)
        self.GIALLO_HEX  = "#C49010"   # giallo honeycomb
        self.BORDO       = "#252525"   # bordi e separatori
        self.VERDE       = "#22c55e"   # punteggio alto
        self.ROSSO       = "#ef4444"   # punteggio basso / errore
        self.GRIGIO      = "#777777"   # testo secondario
        self.CONSOLE_BG  = "#0A0A0A"   # sfondo console
        self.CONSOLE_FG  = "#D4A017"   # testo console
