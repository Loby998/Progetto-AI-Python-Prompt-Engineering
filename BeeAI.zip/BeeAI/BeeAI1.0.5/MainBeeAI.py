from Models.BeeAI import BeeAIApp
import customtkinter as ctk

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

if __name__ == "__main__":
    app = BeeAIApp()
    app.mainloop()
