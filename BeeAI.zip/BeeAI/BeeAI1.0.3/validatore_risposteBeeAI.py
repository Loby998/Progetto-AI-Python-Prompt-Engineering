# =============================================================
#  validatore_risposte.py  —  Backend BeeAI
#  5 iterazioni indipendenti + prompt evolutivo + output terminale
# =============================================================

import json
import requests

# ── CONFIGURAZIONE ───────────────────────────────────────────
URL          = "http://192.168.49.231:11434/api/chat"
MODELLO      = "gpt-oss:20b"
N_ITERAZIONI = 5

SYSTEM_RISPOSTA = (
    "Sei un assistente esperto. Rispondi alla domanda usando SOLO "
    "le informazioni presenti nel testo fornito. "
    "Se la risposta non è nel testo, scrivi 'Informazione non presente nel testo'. "
    "Sii sintetico e diretto."
)

SYSTEM_GIUDICE = (
    "Valuta la risposta da 1 a 10 in base alla fedeltà al testo originale. "
    "Rispondi SOLO con il numero intero (es. 8). Nessuna parola in più."
)


# ── CHIAMATE AL MODELLO ──────────────────────────────────────

def chiama_modello_stream(system_prompt, messaggio, on_token=None):
    """Streaming: chiama on_token(token) per ogni pezzo di testo ricevuto."""
    payload = {
        "model": MODELLO,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user",   "content": messaggio},
        ],
        "stream": True
    }
    risposta_completa = ""
    try:
        with requests.post(URL, json=payload, stream=True, timeout=120) as r:
            r.raise_for_status()
            for riga in r.iter_lines():
                if riga:
                    chunk = json.loads(riga.decode("utf-8"))
                    token = chunk.get("message", {}).get("content", "")
                    risposta_completa += token
                    if on_token:
                        on_token(token)
                    if chunk.get("done", False):
                        break
        return risposta_completa.strip()
    except Exception as e:
        print(f"Errore connessione: {e}")
        return None


def chiama_modello(system_prompt, messaggio):
    """Chiamata semplice senza streaming (usata per la valutazione)."""
    payload = {
        "model": MODELLO,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user",   "content": messaggio},
        ],
        "stream": False
    }
    try:
        r = requests.post(URL, json=payload, timeout=120)
        r.raise_for_status()
        return r.json()["message"]["content"].strip()
    except Exception as e:
        print(f"Errore connessione: {e}")
        return None


# ── GENERAZIONE E VALUTAZIONE ────────────────────────────────

def genera_risposta(testo, domanda, prompt_extra="", on_token=None):
    """Genera una risposta. prompt_extra aggiunge contesto dalle iterazioni precedenti."""
    messaggio = f"TESTO:\n{testo}\n\nDOMANDA:\n{domanda}"
    if prompt_extra:
        messaggio += f"\n\n{prompt_extra}"
    return chiama_modello_stream(SYSTEM_RISPOSTA, messaggio, on_token)


def valuta_risposta(testo, domanda, risposta):
    """Assegna un punteggio da 1 a 10 alla risposta."""
    messaggio = (
        f"TESTO:\n{testo}\n\n"
        f"DOMANDA:\n{domanda}\n\n"
        f"RISPOSTA:\n{risposta}\n\n"
        f"Dai solo il numero da 1 a 10."
    )
    risultato = chiama_modello(SYSTEM_GIUDICE, messaggio)
    if risultato is None:
        return 5
    for parola in risultato.split():
        p = parola.strip(".,!?:/\n")
        if p.isdigit():
            return max(1, min(10, int(p)))
    return 5


# ── CICLO PRINCIPALE: 5 ITERAZIONI INDIPENDENTI ──────────────

def genera_e_valuta(testo, domanda, on_token=None, on_done=None, on_log=None):
    """
    Esegue 5 iterazioni indipendenti di generazione + valutazione.

    Estensione facoltativa:
      Il prompt di ogni iterazione viene arricchito con i punteggi
      e la risposta migliore delle iterazioni precedenti.

    Callback:
      on_token(idx, token)           → token streaming per la card idx
      on_done(idx, risposta, score)  → risposta completata con punteggio
      on_log(messaggio)              → riga di log per la console GUI
    """

    def log(msg):
        print(msg)        # output a terminale (richiesto dal progetto)
        if on_log:
            on_log(msg)   # output alla console GUI

    risultati = []        # lista di (risposta, punteggio)

    # ── Intestazione terminale ──
    log("=" * 58)
    log(f"  BeeAI — Validatore  |  {N_ITERAZIONI} iterazioni")
    log("=" * 58)
    log(f"  DOMANDA: {domanda}")
    log("=" * 58)

    for i in range(N_ITERAZIONI):
        log(f"\n[{i+1}/{N_ITERAZIONI}] Generazione risposta...")

        # ── ESTENSIONE FACOLTATIVA: prompt evolutivo ──────────
        # Ogni iterazione conosce punteggi e risposta migliore
        # delle iterazioni precedenti, così il modello può migliorarsi.
        prompt_extra = ""
        if risultati:
            punteggi_prec   = [r[1] for r in risultati]
            migliore_finora = max(risultati, key=lambda x: x[1])
            prompt_extra = (
                f"CONTESTO ITERAZIONI PRECEDENTI:\n"
                f"Sono già state generate {len(risultati)} risposte "
                f"con punteggi: {punteggi_prec}.\n"
                f"La risposta migliore finora ha punteggio {migliore_finora[1]}/10:\n"
                f"\"{migliore_finora[0][:200]}...\"\n"
                f"Produci una risposta più precisa e completa di quella."
            )

        # ── Genera risposta (streaming verso la card GUI) ─────
        risposta = genera_risposta(
            testo, domanda,
            prompt_extra=prompt_extra,
            on_token=lambda token, idx=i: on_token(idx, token) if on_token else None
        )

        if risposta is None:
            risposta  = "Errore di connessione."
            punteggio = 0
        else:
            log(f"[{i+1}/{N_ITERAZIONI}] Valutazione in corso...")
            punteggio = valuta_risposta(testo, domanda, risposta)

        risultati.append((risposta, punteggio))

        # ── Log risposta e punteggio ──────────────────────────
        log(f"\n  Risposta {i+1}:")
        log(f"  {risposta[:300]}{'...' if len(risposta) > 300 else ''}")
        log(f"  Punteggio: {punteggio}/10")
        log("-" * 58)

        if on_done:
            on_done(i, risposta, punteggio)

    # ── Risultato finale ──────────────────────────────────────
    migliore_idx                      = max(range(N_ITERAZIONI), key=lambda i: risultati[i][1])
    migliore_risposta, migliore_score = risultati[migliore_idx]

    log(f"\n{'='*58}")
    log(f"  MIGLIORE RISPOSTA — iterazione {migliore_idx+1}"
        f" — punteggio {migliore_score}/10")
    log(f"{'='*58}")
    log(f"  {migliore_risposta}")
    log(f"{'='*58}\n")

    return risultati
