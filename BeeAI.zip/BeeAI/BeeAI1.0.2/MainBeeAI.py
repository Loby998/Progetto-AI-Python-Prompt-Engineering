# =============================================================
#  interfaccia.py  —  BeeAI "Cyberpunk Hive" Interface
#  5 iterazioni fisse + pannello console terminale
# =============================================================

import customtkinter as ctk
import tkinter as tk
import threading
import math
import time

from validatore_risposte import genera_e_valuta, MODELLO, N_ITERAZIONI

# ── PALETTE ─────────────────────────────────────────────────
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

NERO        = "#0A0A0A"
NERO_CARD   = "#101010"
NERO_INPUT  = "#181818"
GIALLO      = "#FFC107"
GIALLO_DIM  = "#996600"
GIALLO_GLOW = "#FFD740"
BORDO       = "#252525"
VERDE       = "#22c55e"
ROSSO       = "#ef4444"
GRIGIO      = "#555555"
CONSOLE_BG  = "#0D1117"   # sfondo console terminale
CONSOLE_FG  = "#39FF14"   # verde neon testo console


# ── HONEYCOMB ────────────────────────────────────────────────

def disegna_honeycomb(canvas, larghezza, altezza, size=22, colore="#181818"):
    canvas.delete("all")
    h_hex    = math.sqrt(3) * size
    w_hex    = 2 * size
    offset_y = h_hex / 2
    col = 0
    x   = size
    while x < larghezza + w_hex:
        y = 0 if col % 2 == 0 else offset_y
        while y < altezza + h_hex:
            punti = []
            for i in range(6):
                angolo = math.radians(60 * i + 30)
                punti += [x + size * math.cos(angolo), y + size * math.sin(angolo)]
            canvas.create_polygon(punti, outline=colore, fill="", width=1)
            y += h_hex
        x   += w_hex * 0.75
        col += 1


# ── APP ──────────────────────────────────────────────────────

class BeeAIApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("BeeAI — Validatore Intelligente")
        self.geometry("1300x860")
        self.minsize(1000, 680)
        self.configure(fg_color=NERO)

        self.cards        = {}
        self._completate  = 0
        self._costruisci_ui()

    # ── UI ───────────────────────────────────────────────────

    def _costruisci_ui(self):

        # ── HEADER ──
        self.header = tk.Frame(self, bg="#0D0D0D", height=80)
        self.header.pack(fill="x")
        self.header.pack_propagate(False)

        self.hc_canvas = tk.Canvas(self.header, bg="#0D0D0D", highlightthickness=0, height=80)
        self.hc_canvas.place(x=0, y=0, relwidth=1, relheight=1)
        self.after(100, self._aggiorna_honeycomb)

        tk.Label(self.header, text="🐝", font=("Segoe UI", 28),
                 bg="#0D0D0D", fg=GIALLO).place(x=25, y=18)
        tk.Label(self.header, text="BeeAI", font=("Consolas", 26, "bold"),
                 bg="#0D0D0D", fg=GIALLO).place(x=68, y=18)
        tk.Label(self.header, text="Validatore Intelligente", font=("Consolas", 11),
                 bg="#0D0D0D", fg="#444444").place(x=72, y=55)
        tk.Label(self.header, text=f"⚡  {MODELLO}", font=("Consolas", 10),
                 bg="#0D0D0D", fg="#333333").place(relx=0.98, y=30, anchor="ne")

        ctk.CTkFrame(self, height=2, fg_color=GIALLO, corner_radius=0).pack(fill="x")

        # ── CORPO ──
        corpo = ctk.CTkFrame(self, fg_color="transparent")
        corpo.pack(fill="both", expand=True, padx=20, pady=18)

        # ── PANNELLO SINISTRO (input) ──
        sx = ctk.CTkFrame(corpo, fg_color=NERO_CARD, corner_radius=12,
                          border_width=1, border_color=BORDO, width=320)
        sx.pack(side="left", fill="y")
        sx.pack_propagate(False)

        _lbl_sezione(sx, "📄  TESTO DI RIFERIMENTO")
        self.txt_testo = _textbox(sx, height=200)

        _lbl_sezione(sx, "❓  DOMANDA")
        self.txt_domanda = _textbox(sx, height=80)

        # Badge iterazioni (fisso a 5)
        badge = ctk.CTkFrame(sx, fg_color="#1A1A1A", corner_radius=6, border_width=1, border_color=BORDO)
        badge.pack(fill="x", padx=18, pady=(0, 14))
        ctk.CTkLabel(badge, text="Iterazioni:", text_color=GRIGIO,
                     font=("Consolas", 11)).pack(side="left", padx=10, pady=6)
        ctk.CTkLabel(badge, text=f"{N_ITERAZIONI}  (fisso)", text_color=GIALLO,
                     font=("Consolas", 11, "bold")).pack(side="right", padx=10)

        self.btn_avvia = ctk.CTkButton(
            sx, text="▶  AVVIA ANALISI",
            font=("Consolas", 14, "bold"),
            fg_color=GIALLO, text_color=NERO, hover_color=GIALLO_GLOW,
            height=46, corner_radius=8, command=self._avvia
        )
        self.btn_avvia.pack(fill="x", padx=18, pady=(0, 8))

        self.btn_reset = ctk.CTkButton(
            sx, text="↺  Reset",
            fg_color="transparent", border_width=1, border_color=BORDO,
            text_color=GRIGIO, hover_color="#1A1A1A",
            font=("Consolas", 11), command=self._reset
        )
        self.btn_reset.pack(fill="x", padx=18)

        ctk.CTkFrame(sx, height=1, fg_color=BORDO).pack(fill="x", padx=18, pady=12)

        self.lbl_stato = ctk.CTkLabel(sx, text="In attesa...",
                                       text_color="#444", font=("Consolas", 11))
        self.lbl_stato.pack(anchor="w", padx=20)

        self.progressbar = ctk.CTkProgressBar(sx, progress_color=GIALLO,
                                               fg_color=NERO_INPUT, height=5, corner_radius=2)
        self.progressbar.pack(fill="x", padx=18, pady=(6, 0))
        self.progressbar.set(0)

        # ── Separatore verticale ──
        ctk.CTkFrame(corpo, width=1, fg_color=BORDO).pack(side="left", fill="y", padx=12)

        # ── AREA DESTRA: cards + console ──
        area_dx = ctk.CTkFrame(corpo, fg_color="transparent")
        area_dx.pack(side="left", fill="both", expand=True)

        # Cards risultati (70% altezza)
        self.pannello_dx = ctk.CTkScrollableFrame(area_dx, fg_color="transparent",
                                                   scrollbar_button_color=BORDO)
        self.pannello_dx.pack(fill="both", expand=True)
        self._mostra_placeholder()

        # ── CONSOLE TERMINALE ──
        ctk.CTkFrame(area_dx, height=1, fg_color=BORDO).pack(fill="x", pady=(8, 0))

        console_header = ctk.CTkFrame(area_dx, fg_color="transparent", height=24)
        console_header.pack(fill="x", pady=(4, 2))
        console_header.pack_propagate(False)
        ctk.CTkLabel(console_header, text="◉  CONSOLE OUTPUT",
                     font=("Consolas", 10, "bold"), text_color=CONSOLE_FG).pack(side="left", padx=4)
        ctk.CTkLabel(console_header, text="stdout",
                     font=("Consolas", 9), text_color="#2a2a2a").pack(side="right", padx=4)

        self.console = ctk.CTkTextbox(
            area_dx, height=160,
            fg_color=CONSOLE_BG, text_color=CONSOLE_FG,
            font=("Consolas", 11), corner_radius=6,
            border_width=1, border_color="#1a2a1a",
            wrap="none"
        )
        self.console.pack(fill="x", pady=(0, 0))
        self.console.insert("1.0", "BeeAI console pronta. Avvia un'analisi per vedere l'output...\n")
        self.console.configure(state="disabled")

    # ── HONEYCOMB ────────────────────────────────────────────

    def _aggiorna_honeycomb(self):
        self.update_idletasks()
        w = self.header.winfo_width()
        disegna_honeycomb(self.hc_canvas, w, 80, size=18, colore="#1C1C1C")
        self.hc_canvas.lift()
        for child in self.header.winfo_children():
            if isinstance(child, tk.Label):
                child.lift()

    # ── PLACEHOLDER ──────────────────────────────────────────

    def _mostra_placeholder(self):
        for w in self.pannello_dx.winfo_children():
            w.destroy()
        ctk.CTkLabel(
            self.pannello_dx,
            text="🐝  I risultati appariranno qui...",
            text_color="#252525", font=("Consolas", 15)
        ).pack(pady=100)

    # ── AVVIA ────────────────────────────────────────────────

    def _avvia(self):
        testo   = self.txt_testo.get("1.0", "end-1c").strip()
        domanda = self.txt_domanda.get("1.0", "end-1c").strip()

        if not testo or not domanda:
            self.lbl_stato.configure(text="⚠  Inserisci testo e domanda.", text_color=ROSSO)
            return

        self.btn_avvia.configure(state="disabled", text="⏳  Elaborazione...")
        self.cards       = {}
        self._completate = 0
        self.progressbar.set(0)
        self.lbl_stato.configure(text="🐝  Le api stanno lavorando...", text_color=GIALLO)

        # Pulisci console
        self.console.configure(state="normal")
        self.console.delete("1.0", "end")
        self.console.configure(state="disabled")

        # Crea le 5 card vuote
        for w in self.pannello_dx.winfo_children():
            w.destroy()
        for i in range(N_ITERAZIONI):
            self.cards[i] = self._crea_card(i + 1)

        threading.Thread(
            target=self._thread_lavoro,
            args=(testo, domanda),
            daemon=True
        ).start()

    # ── THREAD DI LAVORO ─────────────────────────────────────

    def _thread_lavoro(self, testo, domanda):
        inizio = time.time()

        def on_token(idx, token):
            widgets = self.cards.get(idx)
            if not widgets:
                return
            def _upd():
                t = widgets["txt"]
                t.configure(state="normal")
                if t.get("1.0", "end-1c") == "⏳  Generazione in corso...":
                    t.delete("1.0", "end")
                t.insert("end", token)
                t.configure(state="disabled")
                t.see("end")
            self.after(0, _upd)

        def on_done(idx, risposta, punteggio):
            self._completate += 1
            perc   = self._completate / N_ITERAZIONI
            colore = VERDE if punteggio >= 7 else (GIALLO if punteggio >= 4 else ROSSO)
            def _upd():
                w = self.cards[idx]
                w["score"].configure(text=f"{punteggio}/10", text_color=colore)
                self.progressbar.set(perc)
                self.lbl_stato.configure(
                    text=f"🐝  {self._completate}/{N_ITERAZIONI} complete",
                    text_color=GIALLO
                )
            self.after(0, _upd)

        def on_log(msg):
            def _upd():
                self.console.configure(state="normal")
                self.console.insert("end", msg + "\n")
                self.console.configure(state="disabled")
                self.console.see("end")
            self.after(0, _upd)

        genera_e_valuta(testo, domanda,
                        on_token=on_token,
                        on_done=on_done,
                        on_log=on_log)

        durata = time.time() - inizio
        self.after(0, lambda: self._fine(durata))

    # ── FINE ─────────────────────────────────────────────────

    def _fine(self, durata):
        self.btn_avvia.configure(state="normal", text="▶  AVVIA ANALISI")
        self.lbl_stato.configure(text=f"✅  Completato in {durata:.1f}s", text_color=VERDE)

        # Evidenzia la migliore
        migliore_idx   = -1
        migliore_score = -1
        for idx, w in self.cards.items():
            try:
                s = int(w["score"].cget("text").replace("/10", ""))
                if s > migliore_score:
                    migliore_score = s
                    migliore_idx   = idx
            except ValueError:
                pass

        if migliore_idx >= 0:
            w = self.cards[migliore_idx]
            w["card"].configure(border_color=GIALLO, border_width=2)
            w["label"].configure(text="⭐  MIGLIORE RISPOSTA", text_color=GIALLO_GLOW)
            # Porta la card migliore in cima
            figli = list(self.pannello_dx.winfo_children())
            if figli:
                w["card"].pack_forget()
                w["card"].pack(fill="x", pady=(0, 12), padx=4, before=figli[0])

    # ── CREA CARD ────────────────────────────────────────────

    def _crea_card(self, numero):
        card = ctk.CTkFrame(self.pannello_dx, fg_color=NERO_CARD,
                            border_width=1, border_color=BORDO, corner_radius=10)
        card.pack(fill="x", pady=(0, 10), padx=4)

        ctk.CTkFrame(card, width=3, fg_color=GIALLO_DIM, corner_radius=3).pack(
            side="left", fill="y", padx=(8, 0), pady=8
        )

        contenuto = ctk.CTkFrame(card, fg_color="transparent")
        contenuto.pack(side="left", fill="both", expand=True)

        header = ctk.CTkFrame(contenuto, fg_color="transparent")
        header.pack(fill="x", padx=12, pady=(8, 4))

        lbl_titolo = ctk.CTkLabel(header, text=f"◈  Risposta {numero}",
                                   font=("Consolas", 12, "bold"), text_color=GRIGIO)
        lbl_titolo.pack(side="left")

        lbl_score = ctk.CTkLabel(header, text="—/10",
                                  font=("Consolas", 16, "bold"), text_color="#333")
        lbl_score.pack(side="right")

        ctk.CTkLabel(header, text="⬡", font=("Segoe UI", 14),
                     text_color="#222").pack(side="right", padx=6)

        txt = ctk.CTkTextbox(contenuto, height=80, fg_color="transparent",
                             text_color="#BBBBBB", wrap="word", font=("Consolas", 12))
        txt.pack(fill="x", padx=10, pady=(0, 8))
        txt.insert("1.0", "⏳  Generazione in corso...")
        txt.configure(state="disabled")

        return {"card": card, "txt": txt, "score": lbl_score, "label": lbl_titolo}

    # ── RESET ────────────────────────────────────────────────

    def _reset(self):
        self.txt_testo.delete("1.0", "end")
        self.txt_domanda.delete("1.0", "end")
        self.progressbar.set(0)
        self.lbl_stato.configure(text="In attesa...", text_color="#444")
        self.cards = {}
        self._mostra_placeholder()
        self.console.configure(state="normal")
        self.console.delete("1.0", "end")
        self.console.insert("1.0", "Console pulita. Pronto per una nuova analisi.\n")
        self.console.configure(state="disabled")


# ── HELPER ───────────────────────────────────────────────────

def _lbl_sezione(parent, testo):
    ctk.CTkLabel(parent, text=testo, font=("Consolas", 11, "bold"),
                 text_color=GIALLO).pack(anchor="w", padx=20, pady=(16, 4))

def _textbox(parent, height):
    t = ctk.CTkTextbox(parent, height=height, corner_radius=8,
                       fg_color=NERO_INPUT, border_color=BORDO, border_width=1,
                       text_color="#CCCCCC", font=("Consolas", 12))
    t.pack(fill="x", padx=15, pady=(0, 6))
    return t


# ── ENTRY POINT ──────────────────────────────────────────────

if __name__ == "__main__":
    app = BeeAIApp()
    app.mainloop()
