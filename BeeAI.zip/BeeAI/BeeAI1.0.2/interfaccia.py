# =============================================================
#  interfaccia.py  —  BeeAI "Cyberpunk Hive" Interface
# =============================================================

import customtkinter as ctk
import tkinter as tk
import threading
import math
import time

from validatore_risposte import genera_e_valuta, MODELLO

# ── PALETTE ─────────────────────────────────────────────────
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

NERO        = "#0A0A0A"
NERO_CARD   = "#101010"
NERO_INPUT  = "#181818"
GIALLO      = "#FFC107"
GIALLO_DIM  = "#996600"
GIALLO_GLOW = "#FFD740"
BORDO       = "#252525"
VERDE       = "#22c55e"
ROSSO       = "#ef4444"
GRIGIO      = "#555555"


# ── FUNZIONE: disegna honeycomb su canvas ────────────────────

def disegna_honeycomb(canvas, larghezza, altezza, size=22, colore="#181818"):
    """Riempie un Canvas tkinter con un pattern a nido d'ape."""
    canvas.delete("all")
    h_hex = math.sqrt(3) * size
    w_hex = 2 * size
    offset_y = h_hex / 2

    col = 0
    x = size
    while x < larghezza + w_hex:
        row = 0
        y_start = 0 if col % 2 == 0 else offset_y
        y = y_start
        while y < altezza + h_hex:
            punti = []
            for i in range(6):
                angolo = math.radians(60 * i + 30)
                punti += [x + size * math.cos(angolo), y + size * math.sin(angolo)]
            canvas.create_polygon(punti, outline=colore, fill="", width=1)
            y += h_hex
            row += 1
        x += w_hex * 0.75
        col += 1


# ── APP PRINCIPALE ───────────────────────────────────────────

class BeeAIApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("BeeAI — Validatore Intelligente")
        self.geometry("1200x820")
        self.minsize(950, 650)
        self.configure(fg_color=NERO)

        self.cards = {}   # {idx: {"txt": widget, "score": widget, "card": frame, "label": widget}}
        self._costruisci_ui()

    # ── COSTRUZIONE INTERFACCIA ──────────────────────────────

    def _costruisci_ui(self):

        # ── HEADER con honeycomb ──
        self.header = tk.Frame(self, bg="#0D0D0D", height=80)
        self.header.pack(fill="x")
        self.header.pack_propagate(False)

        # Canvas honeycomb (sfondo header)
        self.hc_canvas = tk.Canvas(self.header, bg="#0D0D0D", highlightthickness=0, height=80)
        self.hc_canvas.place(x=0, y=0, relwidth=1, relheight=1)
        self.after(100, self._aggiorna_honeycomb)

        # Logo BeeAI
        tk.Label(self.header, text="🐝", font=("Segoe UI", 28), bg="#0D0D0D", fg=GIALLO).place(x=25, y=18)
        tk.Label(self.header, text="BeeAI", font=("Consolas", 26, "bold"), bg="#0D0D0D", fg=GIALLO).place(x=68, y=18)
        tk.Label(self.header, text="Validatore Intelligente", font=("Consolas", 11), bg="#0D0D0D", fg="#444444").place(x=72, y=55)

        # Modello a destra
        tk.Label(self.header, text=f"⚡  {MODELLO}", font=("Consolas", 10), bg="#0D0D0D", fg="#333333").place(relx=0.98, y=30, anchor="ne")

        # ── Linea gialla separatrice ──
        ctk.CTkFrame(self, height=2, fg_color=GIALLO, corner_radius=0).pack(fill="x")

        # ── CORPO ──
        corpo = ctk.CTkFrame(self, fg_color="transparent")
        corpo.pack(fill="both", expand=True, padx=20, pady=18)

        # ── PANNELLO SINISTRO ──
        pannello_sx = ctk.CTkFrame(corpo, fg_color=NERO_CARD, corner_radius=12,
                                   border_width=1, border_color=BORDO, width=340)
        pannello_sx.pack(side="left", fill="y")
        pannello_sx.pack_propagate(False)

        # Titolo pannello
        _lbl_sezione(pannello_sx, "📄  TESTO DI RIFERIMENTO")
        self.txt_testo = _textbox(pannello_sx, height=190)

        _lbl_sezione(pannello_sx, "❓  DOMANDA")
        self.txt_domanda = _textbox(pannello_sx, height=75)

        # N° risposte
        riga = ctk.CTkFrame(pannello_sx, fg_color="transparent")
        riga.pack(fill="x", padx=18, pady=(0, 12))
        ctk.CTkLabel(riga, text="Numero di risposte:", text_color=GRIGIO,
                     font=("Consolas", 11)).pack(side="left")
        self.combo_num = ctk.CTkComboBox(riga, values=["1", "2", "3", "5"],
                                          width=65, border_color=BORDO,
                                          button_color=BORDO, fg_color=NERO_INPUT,
                                          font=("Consolas", 12))
        self.combo_num.set("3")
        self.combo_num.pack(side="right")

        # Bottone AVVIA
        self.btn_avvia = ctk.CTkButton(
            pannello_sx, text="▶  AVVIA ANALISI",
            font=("Consolas", 14, "bold"),
            fg_color=GIALLO, text_color=NERO, hover_color=GIALLO_GLOW,
            height=46, corner_radius=8, command=self._avvia
        )
        self.btn_avvia.pack(fill="x", padx=18, pady=(5, 8))

        self.btn_reset = ctk.CTkButton(
            pannello_sx, text="↺  Reset",
            fg_color="transparent", border_width=1, border_color=BORDO,
            text_color=GRIGIO, hover_color="#1A1A1A",
            font=("Consolas", 11), command=self._reset
        )
        self.btn_reset.pack(fill="x", padx=18)

        # Progress
        ctk.CTkFrame(pannello_sx, height=1, fg_color=BORDO).pack(fill="x", padx=18, pady=14)

        self.lbl_stato = ctk.CTkLabel(pannello_sx, text="In attesa...",
                                       text_color="#444", font=("Consolas", 11))
        self.lbl_stato.pack(anchor="w", padx=20)

        self.progressbar = ctk.CTkProgressBar(pannello_sx, progress_color=GIALLO,
                                               fg_color=NERO_INPUT, height=5, corner_radius=2)
        self.progressbar.pack(fill="x", padx=18, pady=(6, 0))
        self.progressbar.set(0)

        # ── Separatore verticale ──
        ctk.CTkFrame(corpo, width=1, fg_color=BORDO).pack(side="left", fill="y", padx=14)

        # ── PANNELLO DESTRO (risultati) ──
        self.pannello_dx = ctk.CTkScrollableFrame(corpo, fg_color="transparent",
                                                   scrollbar_button_color=BORDO)
        self.pannello_dx.pack(side="left", fill="both", expand=True)

        self._mostra_placeholder()

    # ── PLACEHOLDER ─────────────────────────────────────────

    def _mostra_placeholder(self):
        for w in self.pannello_dx.winfo_children():
            w.destroy()
        ctk.CTkLabel(
            self.pannello_dx,
            text="🐝  I risultati appariranno qui...",
            text_color="#252525", font=("Consolas", 15)
        ).pack(pady=180)

    # ── HONEYCOMB (ridisegna quando finestra cambia dimensione) ──

    def _aggiorna_honeycomb(self):
        self.update_idletasks()
        w = self.header.winfo_width()
        disegna_honeycomb(self.hc_canvas, w, 80, size=18, colore="#1C1C1C")
        self.hc_canvas.lift()  # manda canvas in fondo (i label stanno sopra)
        # Rimetti le label sopra
        for child in self.header.winfo_children():
            if isinstance(child, tk.Label):
                child.lift()

    # ── AVVIA ────────────────────────────────────────────────

    def _avvia(self):
        testo   = self.txt_testo.get("1.0", "end-1c").strip()
        domanda = self.txt_domanda.get("1.0", "end-1c").strip()
        n       = int(self.combo_num.get())

        if not testo or not domanda:
            self.lbl_stato.configure(text="⚠  Inserisci testo e domanda.", text_color=ROSSO)
            return

        # Reset UI
        self.btn_avvia.configure(state="disabled", text="⏳  Elaborazione...")
        self.cards = {}
        self._completate = 0
        self._n_totale   = n
        self.progressbar.set(0)
        self.lbl_stato.configure(text=f"🐝  Le api stanno lavorando...", text_color=GIALLO)

        # Crea le card vuote (una per ogni risposta)
        for w in self.pannello_dx.winfo_children():
            w.destroy()
        for i in range(n):
            self.cards[i] = self._crea_card(i + 1)

        # Avvia in background (un solo thread per non bloccare la UI)
        threading.Thread(
            target=self._thread_lavoro,
            args=(testo, domanda, n),
            daemon=True
        ).start()

    # ── THREAD DI LAVORO ─────────────────────────────────────

    def _thread_lavoro(self, testo, domanda, n):
        inizio = time.time()

        def on_token(idx, token):
            widgets = self.cards.get(idx)
            if not widgets:
                return
            def _update():
                t = widgets["txt"]
                t.configure(state="normal")
                if t.get("1.0", "end-1c") == "⏳  Generazione in corso...":
                    t.delete("1.0", "end")
                t.insert("end", token)
                t.configure(state="disabled")
                t.see("end")
            self.after(0, _update)

        def on_done(idx, risposta, punteggio):
            self._completate += 1
            perc = self._completate / self._n_totale
            colore = VERDE if punteggio >= 7 else (GIALLO if punteggio >= 4 else ROSSO)
            def _update():
                w = self.cards[idx]
                w["score"].configure(text=f"{punteggio}/10", text_color=colore)
                self.progressbar.set(perc)
                self.lbl_stato.configure(
                    text=f"🐝  {self._completate}/{self._n_totale} complete",
                    text_color=GIALLO
                )
            self.after(0, _update)

        genera_e_valuta(testo, domanda, n, on_token=on_token, on_done=on_done)

        durata = time.time() - inizio
        self.after(0, lambda: self._fine(durata))

    # ── FINE ELABORAZIONE ────────────────────────────────────

    def _fine(self, durata):
        self.btn_avvia.configure(state="normal", text="▶  AVVIA ANALISI")
        self.lbl_stato.configure(text=f"✅  Completato in {durata:.1f}s", text_color=VERDE)

        # Evidenzia la migliore
        migliore_idx  = -1
        migliore_score = -1
        for idx, w in self.cards.items():
            try:
                s = int(w["score"].cget("text").replace("/10", ""))
                if s > migliore_score:
                    migliore_score = s
                    migliore_idx   = idx
            except ValueError:
                pass

        if migliore_idx >= 0:
            w = self.cards[migliore_idx]
            w["card"].configure(border_color=GIALLO, border_width=2)
            w["label"].configure(text="⭐  MIGLIORE RISPOSTA", text_color=GIALLO_GLOW)
            # Sposta la card migliore in cima
            w["card"].pack_forget()
            w["card"].pack(fill="x", pady=(0, 12), padx=4, before=list(
                self.pannello_dx.winfo_children()
            )[0] if self.pannello_dx.winfo_children() else None)

    # ── CREA CARD (vuota, si riempie via streaming) ──────────

    def _crea_card(self, numero):
        card = ctk.CTkFrame(self.pannello_dx, fg_color=NERO_CARD,
                            border_width=1, border_color=BORDO, corner_radius=10)
        card.pack(fill="x", pady=(0, 12), padx=4)

        # Striscia gialla laterale (effetto hex-panel)
        ctk.CTkFrame(card, width=3, fg_color=GIALLO_DIM, corner_radius=3).pack(
            side="left", fill="y", padx=(8, 0), pady=8
        )

        contenuto = ctk.CTkFrame(card, fg_color="transparent")
        contenuto.pack(side="left", fill="both", expand=True)

        header = ctk.CTkFrame(contenuto, fg_color="transparent")
        header.pack(fill="x", padx=12, pady=(10, 4))

        lbl_titolo = ctk.CTkLabel(header, text=f"◈  Risposta {numero}",
                                   font=("Consolas", 12, "bold"), text_color=GRIGIO)
        lbl_titolo.pack(side="left")

        lbl_score = ctk.CTkLabel(header, text="—/10",
                                  font=("Consolas", 16, "bold"), text_color="#333")
        lbl_score.pack(side="right")

        # Esagono decorativo
        ctk.CTkLabel(header, text="⬡", font=("Segoe UI", 14), text_color="#222").pack(
            side="right", padx=6
        )

        txt = ctk.CTkTextbox(contenuto, height=90, fg_color="transparent",
                             text_color="#BBBBBB", wrap="word",
                             font=("Consolas", 12))
        txt.pack(fill="x", padx=10, pady=(0, 10))
        txt.insert("1.0", "⏳  Generazione in corso...")
        txt.configure(state="disabled")

        return {"card": card, "txt": txt, "score": lbl_score, "label": lbl_titolo}

    # ── RESET ────────────────────────────────────────────────

    def _reset(self):
        self.txt_testo.delete("1.0", "end")
        self.txt_domanda.delete("1.0", "end")
        self.progressbar.set(0)
        self.lbl_stato.configure(text="In attesa...", text_color="#444")
        self.cards = {}
        self._mostra_placeholder()


# ── HELPER UI ────────────────────────────────────────────────

def _lbl_sezione(parent, testo):
    ctk.CTkLabel(parent, text=testo, font=("Consolas", 11, "bold"),
                 text_color=GIALLO).pack(anchor="w", padx=20, pady=(16, 4))

def _textbox(parent, height):
    t = ctk.CTkTextbox(parent, height=height, corner_radius=8,
                       fg_color=NERO_INPUT, border_color=BORDO, border_width=1,
                       text_color="#CCCCCC", font=("Consolas", 12))
    t.pack(fill="x", padx=15, pady=(0, 6))
    return t


# ── ENTRY POINT ──────────────────────────────────────────────

if __name__ == "__main__":
    app = BeeAIApp()
    app.mainloop()
