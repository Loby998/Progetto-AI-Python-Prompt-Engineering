# =============================================================
#  validatore_risposte.py  —  Backend BeeAI
#  Usa il modello e l'URL del professore + streaming
# =============================================================

import json
import requests

# ── CONFIGURAZIONE (dal professore) ─────────────────────────
URL     = "http://192.168.49.231:11434/api/chat"
MODELLO = "gpt-oss:20b"

SYSTEM_RISPOSTA = (
    "Sei un assistente esperto. Rispondi alla domanda usando SOLO "
    "le informazioni presenti nel testo fornito. "
    "Se la risposta non è nel testo, scrivi 'Informazione non presente nel testo'. "
    "Sii sintetico e diretto."
)

SYSTEM_GIUDICE = (
    "Valuta la risposta da 1 a 10 in base alla fedeltà al testo originale. "
    "Rispondi SOLO con il numero intero (es. 8). Nessuna parola in più."
)

# ── CHIAMATA CON STREAMING ────────────────────────────────────

def chiama_modello_stream(system_prompt, messaggio, on_token=None):
    """Chiama il modello con streaming. Chiama on_token(token) per ogni pezzo di testo."""
    payload = {
        "model": MODELLO,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user",   "content": messaggio},
        ],
        "stream": True
    }

    risposta_completa = ""

    try:
        with requests.post(URL, json=payload, stream=True, timeout=120) as r:
            r.raise_for_status()
            for riga in r.iter_lines():
                if riga:
                    chunk = json.loads(riga.decode("utf-8"))
                    token = chunk.get("message", {}).get("content", "")
                    risposta_completa += token
                    if on_token:
                        on_token(token)
                    if chunk.get("done", False):
                        break
        return risposta_completa.strip()

    except Exception as e:
        print(f"Errore connessione: {e}")
        return None


# ── CHIAMATA SENZA STREAMING (per il giudice) ─────────────────

def chiama_modello(system_prompt, messaggio):
    """Chiamata semplice senza streaming (usata per la valutazione)."""
    payload = {
        "model": MODELLO,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user",   "content": messaggio},
        ],
        "stream": False
    }

    try:
        r = requests.post(URL, json=payload, timeout=120)
        r.raise_for_status()
        return r.json()["message"]["content"].strip()
    except Exception as e:
        print(f"Errore connessione: {e}")
        return None


# ── GENERAZIONE E VALUTAZIONE ──────────────────────────────────

def genera_risposta(testo, domanda, on_token=None):
    messaggio = f"TESTO:\n{testo}\n\nDOMANDA:\n{domanda}"
    return chiama_modello_stream(SYSTEM_RISPOSTA, messaggio, on_token)


def valuta_risposta(testo, domanda, risposta):
    messaggio = (
        f"TESTO:\n{testo}\n\n"
        f"DOMANDA:\n{domanda}\n\n"
        f"RISPOSTA:\n{risposta}\n\n"
        f"Dai solo il numero da 1 a 10."
    )
    risultato = chiama_modello(SYSTEM_GIUDICE, messaggio)

    if risultato is None:
        return 5

    for parola in risultato.split():
        p = parola.strip(".,!?:/\n")
        if p.isdigit():
            return max(1, min(10, int(p)))
    return 5


# ── ESECUZIONE SEQUENZIALE (senza thread pool) ────────────────

def genera_e_valuta(testo, domanda, n, on_token=None, on_done=None):
    """
    Genera e valuta N risposte una alla volta (sequenziale).
    - on_token(idx, token): chiamato per ogni token in streaming
    - on_done(idx, risposta, punteggio): chiamato quando una risposta è completa
    """
    risultati = []

    for i in range(n):
        risposta = genera_risposta(
            testo, domanda,
            on_token=lambda token, idx=i: on_token(idx, token) if on_token else None
        )

        if risposta is None:
            risposta  = "Errore di connessione."
            punteggio = 0
        else:
            punteggio = valuta_risposta(testo, domanda, risposta)

        risultati.append((risposta, punteggio))

        if on_done:
            on_done(i, risposta, punteggio)

    return risultati
