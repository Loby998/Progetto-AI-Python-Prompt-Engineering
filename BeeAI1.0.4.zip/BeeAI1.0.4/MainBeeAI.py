from Models.BeeAI import *
from Models.colors import *
from Models.HoneycombCanvas import *
import customtkinter as ctk

# ── PALETTE ─────────────────────────────────────────────────
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")


# ── ENTRY POINT ──────────────────────────────────────────────

if __name__ == "__main__":
    app = BeeAIApp()
    app.mainloop()
