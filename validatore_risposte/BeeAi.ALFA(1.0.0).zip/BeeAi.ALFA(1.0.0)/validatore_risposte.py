# =============================================================
#  validatore_risposte.py  —  Logica backend
#  Contiene solo le funzioni per chiamare Ollama e valutare
#  le risposte. L'interfaccia grafica è in interfaccia.py
# =============================================================

import requests
from concurrent.futures import ThreadPoolExecutor, as_completed


# ── CONFIGURAZIONE ───────────────────────────────────────────

URL     = "http://localhost:11434/api/chat"
MODELLO = "qwen2.5:1.5b-instruct"

# Prompt migliorato: istruzioni più esplicite e strutturate
SYSTEM_RISPOSTA = (
    "Sei un assistente esperto nell'analisi di testi. "
    "Riceverai un testo e una domanda. "
    "Devi rispondere alla domanda usando SOLO le informazioni presenti nel testo fornito. "
    "La risposta deve essere completa, chiara e in italiano. "
    "Non inventare informazioni non presenti nel testo. "
    "Vai diretto al punto senza frasi introduttive come 'In base al testo...'."
)

# Prompt migliorato: criteri di valutazione espliciti
SYSTEM_GIUDICE = (
    "Sei un valutatore preciso. Riceverai un testo originale, una domanda e una risposta. "
    "Valuta la risposta assegnando un punteggio intero da 1 a 10 secondo questi criteri:\n"
    "- 9-10: risposta completa, accurata, chiara, basata sul testo\n"
    "- 7-8:  risposta corretta ma incompleta o poco chiara\n"
    "- 5-6:  risposta parzialmente corretta o con qualche imprecisione\n"
    "- 3-4:  risposta vaga, fuori tema o con errori importanti\n"
    "- 1-2:  risposta del tutto errata o inventata\n"
    "Rispondi ESCLUSIVAMENTE con il numero. Nessun altro testo."
)


# ── FUNZIONI BASE ─────────────────────────────────────────────

def chiama_modello(system_prompt, messaggio_utente):
    """
    Invia un messaggio a Ollama e restituisce la risposta come stringa.
    Restituisce None se Ollama non è raggiungibile o si verifica un errore.
    """
    payload = {
        "model": MODELLO,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user",   "content": messaggio_utente},
        ],
        "stream": False,
    }

    try:
        risposta = requests.post(URL, json=payload, timeout=90)
        risposta.raise_for_status()
        return risposta.json()["message"]["content"].strip()

    except requests.exceptions.ConnectionError:
        return None  # Ollama non avviato

    except Exception as e:
        print(f"Errore chiamata modello: {e}")
        return None


def genera_risposta(testo, domanda):
    """
    Genera una risposta alla domanda basandosi esclusivamente sul testo.
    """
    messaggio = (
        f"TESTO:\n{testo}\n\n"
        f"DOMANDA:\n{domanda}\n\n"
        f"Rispondi alla domanda basandoti solo sul testo sopra."
    )
    return chiama_modello(SYSTEM_RISPOSTA, messaggio)


def valuta_risposta(testo, domanda, risposta):
    """
    Chiede al modello di valutare la risposta con un punteggio da 1 a 10.
    Restituisce il punteggio come intero. Default 5 se non parsabile.
    """
    messaggio = (
        f"TESTO ORIGINALE:\n{testo}\n\n"
        f"DOMANDA:\n{domanda}\n\n"
        f"RISPOSTA DA VALUTARE:\n{risposta}\n\n"
        f"Dai un punteggio da 1 a 10. SOLO il numero."
    )

    risultato = chiama_modello(SYSTEM_GIUDICE, messaggio)

    if risultato is None:
        return 0

    # Cerca il primo numero valido nella risposta del modello
    for parola in risultato.split():
        parola_pulita = parola.strip(".,!?:/\n")
        if parola_pulita.isdigit():
            return max(1, min(10, int(parola_pulita)))

    return 5  # valore di fallback


# ── ESECUZIONE PARALLELA ──────────────────────────────────────

def genera_e_valuta_parallelo(testo, domanda, n, callback=None):
    """
    Genera e valuta N risposte in parallelo usando thread multipli.
    Molto più veloce rispetto all'esecuzione sequenziale.

    Parametri:
    - testo, domanda: input dell'utente
    - n: numero di risposte da generare
    - callback(idx, risposta, punteggio): chiamato appena ogni risposta è pronta
      (utile per aggiornare la UI in tempo reale)

    Restituisce: lista di tuple (risposta, punteggio) ordinata per indice.
    """
    risultati = {}

    def elabora_singola(idx):
        """Genera e valuta una singola risposta (gira in un thread separato)."""
        risposta = genera_risposta(testo, domanda)

        if risposta is None:
            return idx, None, 0

        punteggio = valuta_risposta(testo, domanda, risposta)
        return idx, risposta, punteggio

    # Esegue tutte le chiamate in parallelo (max 5 thread contemporanei)
    with ThreadPoolExecutor(max_workers=min(n, 5)) as executor:
        futures = [executor.submit(elabora_singola, i) for i in range(n)]

        for future in as_completed(futures):
            idx, risposta, punteggio = future.result()
            risultati[idx] = (risposta, punteggio)

            # Notifica l'interfaccia che una risposta è pronta
            if callback:
                callback(idx, risposta, punteggio)

    # Restituisce i risultati ordinati per indice originale
    return [risultati[i] for i in range(n) if i in risultati]