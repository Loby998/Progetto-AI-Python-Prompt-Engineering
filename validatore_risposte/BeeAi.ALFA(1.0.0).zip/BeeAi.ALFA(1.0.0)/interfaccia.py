# =============================================================
#  interfaccia.py  —  Interfaccia grafica Validatore AI
#  Importa la logica da: validatore_risposte.py
#  Stile: dark, clean, futuristico
# =============================================================

import tkinter as tk
from tkinter import scrolledtext
import threading
import time

# Importa solo le funzioni di logica dal file backend
from validatore_risposte import genera_risposta, valuta_risposta


# ── COSTANTI DI CONFIGURAZIONE ──────────────────────────────
NUM_RISPOSTE = 3
NOME_MODELLO = "qwen2.5:1.5b-instruct"


# ── PALETTE COLORI ───────────────────────────────────────────
SFONDO      = "#080808"   # sfondo principale
PANNELLO    = "#101010"   # pannelli e card
INPUT_BG    = "#151515"   # sfondo campi di testo
BORDO       = "#1E1E1E"   # bordi sottili
GIALLO      = "#FFD600"   # accento principale
GIALLO_SC   = "#CC9900"   # giallo scuro (hover / disabilitato)
TESTO       = "#EFEFEF"   # testo principale
TESTO_MED   = "#777777"   # testo secondario
TESTO_DIM   = "#333333"   # testo placeholder
VERDE       = "#22C55E"   # successo
ROSSO       = "#EF4444"   # errore


# ── FONT ─────────────────────────────────────────────────────
FONT_TITOLO   = ("Segoe UI", 15, "bold")
FONT_LABEL    = ("Segoe UI", 8)
FONT_BODY     = ("Segoe UI", 10)
FONT_NUMERO   = ("Segoe UI", 20, "bold")
FONT_BTN      = ("Segoe UI", 10, "bold")
FONT_STATUS   = ("Segoe UI", 9)
FONT_PICCOLO  = ("Segoe UI", 8)


# =============================================================
#  WIDGET PERSONALIZZATI
# =============================================================

class BarraPunteggio(tk.Canvas):
    """
    Barra orizzontale sottile che rappresenta il punteggio.
    Verde se alto, giallo se medio, rosso se basso.
    """
    def __init__(self, parent, punteggio, larghezza=260, altezza=3):
        super().__init__(parent, width=larghezza, height=altezza,
                         bg=PANNELLO, highlightthickness=0)

        # Sfondo grigio scuro
        self.create_rectangle(0, 0, larghezza, altezza, fill=BORDO, outline="")

        # Parte colorata proporzionale al punteggio
        riempimento = int((punteggio / 10) * larghezza)
        if punteggio >= 7:
            colore = VERDE
        elif punteggio >= 4:
            colore = GIALLO
        else:
            colore = ROSSO

        self.create_rectangle(0, 0, riempimento, altezza, fill=colore, outline="")


class CardRisposta(tk.Frame):
    """
    Card che mostra una singola risposta con punteggio.
    Se è la migliore, ha un bordo giallo a sinistra.
    """
    def __init__(self, parent, numero, testo, punteggio, migliore=False):
        super().__init__(parent, bg=PANNELLO)

        # Bordo sinistro: giallo se migliore, grigio scuro se no
        colore_bordo = GIALLO if migliore else BORDO
        tk.Frame(self, width=3, bg=colore_bordo).pack(side="left", fill="y")

        contenuto = tk.Frame(self, bg=PANNELLO)
        contenuto.pack(side="left", fill="both", expand=True, padx=16, pady=14)

        # ── Riga header: etichetta + punteggio ──
        header = tk.Frame(contenuto, bg=PANNELLO)
        header.pack(fill="x")

        etichetta = "  Migliore" if migliore else f"  Risposta {numero}"
        colore_label = GIALLO if migliore else TESTO_MED
        tk.Label(header, text=etichetta, font=FONT_LABEL,
                 fg=colore_label, bg=PANNELLO).pack(side="left")

        # Punteggio numerico in alto a destra
        colore_num = VERDE if punteggio >= 7 else (GIALLO if punteggio >= 4 else ROSSO)
        tk.Label(header, text=f"{punteggio}",
                 font=FONT_NUMERO, fg=colore_num, bg=PANNELLO).pack(side="right")
        tk.Label(header, text="/10",
                 font=FONT_BODY, fg=TESTO_MED, bg=PANNELLO).pack(side="right", pady=(8, 0))

        # ── Barra punteggio ──
        BarraPunteggio(contenuto, punteggio).pack(anchor="w", pady=(6, 10))

        # ── Testo della risposta ──
        testo_widget = scrolledtext.ScrolledText(
            contenuto,
            height=4,
            wrap="word",
            bg=INPUT_BG,
            fg=TESTO if migliore else TESTO_MED,
            font=FONT_BODY,
            relief="flat",
            bd=0,
            selectbackground=GIALLO_SC,
            insertbackground=GIALLO,
        )
        testo_widget.pack(fill="x")
        testo_widget.insert("1.0", testo)
        testo_widget.configure(state="disabled")


class ProgressoRisposte(tk.Frame):
    """
    Indicatore di avanzamento: mostra N step come piccoli segmenti.
    Ogni segmento si illumina quando la risposta corrispondente è pronta.
    """
    def __init__(self, parent, n):
        super().__init__(parent, bg=SFONDO)
        self.segmenti = []
        for _ in range(n):
            seg = tk.Frame(self, width=28, height=3, bg=BORDO)
            seg.pack(side="left", padx=2)
            self.segmenti.append(seg)

    def attiva(self, indice):
        """Illumina il segmento all'indice dato."""
        if indice < len(self.segmenti):
            self.segmenti[indice].configure(bg=GIALLO)

    def completa(self, indice, successo=True):
        """Segna il segmento come completato (verde) o errore (rosso)."""
        if indice < len(self.segmenti):
            self.segmenti[indice].configure(bg=VERDE if successo else ROSSO)

    def reset(self):
        """Riporta tutti i segmenti allo stato iniziale."""
        for seg in self.segmenti:
            seg.configure(bg=BORDO)


# =============================================================
#  APPLICAZIONE PRINCIPALE
# =============================================================

class App(tk.Tk):
    """
    Finestra principale dell'applicazione.
    Gestisce il layout, l'input dell'utente e mostra i risultati.
    """

    def __init__(self):
        super().__init__()
        self.title("Validatore AI")
        self.configure(bg=SFONDO)
        self.geometry("1020x720")
        self.minsize(820, 600)

        self._costruisci_interfaccia()

    # ─────────────────────────────────────────────────────────
    #  COSTRUZIONE INTERFACCIA
    # ─────────────────────────────────────────────────────────

    def _costruisci_interfaccia(self):
        """Assembla tutti i componenti dell'interfaccia."""
        self._header()
        self._corpo()
        self._statusbar()

    def _header(self):
        """Intestazione: titolo + info modello."""
        hdr = tk.Frame(self, bg=SFONDO)
        hdr.pack(fill="x", padx=28, pady=(22, 0))

        tk.Label(hdr, text="Validatore AI",
                 font=FONT_TITOLO, fg=TESTO, bg=SFONDO).pack(side="left")

        tk.Label(hdr, text=NOME_MODELLO,
                 font=FONT_PICCOLO, fg=TESTO_MED, bg=SFONDO).pack(side="right", pady=4)

        # Linea separatrice gialla sottile
        tk.Frame(self, height=1, bg=GIALLO).pack(fill="x", padx=28, pady=(10, 0))

    def _corpo(self):
        """Corpo principale: pannello sinistro (input) + destro (output)."""
        corpo = tk.Frame(self, bg=SFONDO)
        corpo.pack(fill="both", expand=True, padx=28, pady=20)

        # Colonna sinistra — input
        sinistra = tk.Frame(corpo, bg=SFONDO, width=340)
        sinistra.pack(side="left", fill="y", padx=(0, 20))
        sinistra.pack_propagate(False)
        self._pannello_input(sinistra)

        # Separatore verticale
        tk.Frame(corpo, width=1, bg=BORDO).pack(side="left", fill="y")

        # Colonna destra — risultati
        destra = tk.Frame(corpo, bg=SFONDO)
        destra.pack(side="left", fill="both", expand=True, padx=(20, 0))
        self._pannello_output(destra)

    def _pannello_input(self, parent):
        """Pannello sinistro: campi testo, domanda e pulsanti."""

        # ── Campo Testo ──
        self._label_sezione(parent, "Testo")
        self.campo_testo = scrolledtext.ScrolledText(
            parent, height=13, wrap="word",
            bg=INPUT_BG, fg=TESTO, font=FONT_BODY,
            relief="flat", bd=0,
            insertbackground=GIALLO,
            selectbackground=GIALLO_SC,
        )
        self.campo_testo.pack(fill="x", pady=(4, 18))
        self._aggiungi_placeholder(self.campo_testo, "Incolla il testo qui...")

        # ── Campo Domanda ──
        self._label_sezione(parent, "Domanda")
        self.campo_domanda = tk.Text(
            parent, height=3, wrap="word",
            bg=INPUT_BG, fg=TESTO, font=FONT_BODY,
            relief="flat", bd=0,
            insertbackground=GIALLO,
            selectbackground=GIALLO_SC,
        )
        self.campo_domanda.pack(fill="x", pady=(4, 24))
        self._aggiungi_placeholder(self.campo_domanda, "Scrivi la domanda...")

        # ── Pulsante AVVIA ──
        self.btn_avvia = tk.Button(
            parent,
            text="Avvia analisi",
            font=FONT_BTN,
            bg=GIALLO,
            fg=SFONDO,
            activebackground=GIALLO_SC,
            activeforeground=SFONDO,
            relief="flat",
            bd=0,
            padx=0,
            pady=11,
            cursor="hand2",
            command=self._avvia,
        )
        self.btn_avvia.pack(fill="x", pady=(0, 8))

        # ── Pulsante Reset ──
        tk.Button(
            parent,
            text="Reset",
            font=FONT_STATUS,
            bg=PANNELLO,
            fg=TESTO_MED,
            activebackground=BORDO,
            activeforeground=TESTO,
            relief="flat",
            bd=0,
            pady=8,
            cursor="hand2",
            command=self._reset,
        ).pack(fill="x")

    def _pannello_output(self, parent):
        """Pannello destro: progresso + lista di card con le risposte."""

        # ── Header risultati + barra progresso ──
        top = tk.Frame(parent, bg=SFONDO)
        top.pack(fill="x", pady=(0, 14))

        self._label_sezione(top, "Risultati", inline=True)

        self.progresso = ProgressoRisposte(top, NUM_RISPOSTE)
        self.progresso.pack(side="right", anchor="s", pady=2)

        # ── Area scrollabile per le card ──
        canvas = tk.Canvas(parent, bg=SFONDO, highlightthickness=0)
        scrollbar = tk.Scrollbar(parent, orient="vertical",
                                 command=canvas.yview,
                                 bg=BORDO, troughcolor=SFONDO)

        self._area_card = tk.Frame(canvas, bg=SFONDO)
        self._area_card.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas.create_window((0, 0), window=self._area_card, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        canvas.bind_all("<MouseWheel>",
            lambda e: canvas.yview_scroll(-1 * (e.delta // 120), "units"))

        self._canvas = canvas
        self._mostra_stato_vuoto()

    def _statusbar(self):
        """Barra di stato in fondo alla finestra."""
        barra = tk.Frame(self, bg=PANNELLO, height=30)
        barra.pack(fill="x", side="bottom")
        barra.pack_propagate(False)

        # Pallino di stato colorato
        self._dot_canvas = tk.Canvas(barra, width=8, height=8,
                                     bg=PANNELLO, highlightthickness=0)
        self._dot_canvas.pack(side="left", padx=(16, 6), pady=11)
        self._dot = self._dot_canvas.create_oval(0, 0, 8, 8, fill=TESTO_DIM)

        # Testo di stato
        self._var_status = tk.StringVar(value="Pronto")
        tk.Label(barra, textvariable=self._var_status,
                 font=FONT_STATUS, fg=TESTO_MED, bg=PANNELLO).pack(side="left")

        # Tempo di elaborazione (mostrato a destra)
        self._var_tempo = tk.StringVar(value="")
        tk.Label(barra, textvariable=self._var_tempo,
                 font=FONT_STATUS, fg=TESTO_DIM, bg=PANNELLO).pack(side="right", padx=16)


    # ─────────────────────────────────────────────────────────
    #  HELPER UI
    # ─────────────────────────────────────────────────────────

    def _label_sezione(self, parent, testo, inline=False):
        """Etichetta piccola per identificare una sezione."""
        lbl = tk.Label(parent, text=testo.upper(),
                       font=FONT_LABEL, fg=TESTO_MED, bg=SFONDO)
        if inline:
            lbl.pack(side="left", anchor="s", pady=2)
        else:
            lbl.pack(anchor="w")

    def _aggiungi_placeholder(self, widget, testo):
        """
        Aggiunge un testo grigio al widget quando è vuoto,
        che scompare quando l'utente clicca.
        """
        widget._placeholder = testo
        widget.insert("1.0", testo)
        widget.configure(fg=TESTO_DIM)

        def on_focus_in(e):
            if widget.get("1.0", "end-1c") == testo:
                widget.delete("1.0", "end")
                widget.configure(fg=TESTO)

        def on_focus_out(e):
            if not widget.get("1.0", "end-1c").strip():
                widget.insert("1.0", testo)
                widget.configure(fg=TESTO_DIM)

        widget.bind("<FocusIn>", on_focus_in)
        widget.bind("<FocusOut>", on_focus_out)

    def _leggi_campo(self, widget):
        """Legge il testo da un campo ignorando il placeholder."""
        testo = widget.get("1.0", "end-1c").strip()
        return "" if testo == widget._placeholder else testo

    def _set_status(self, messaggio, colore=TESTO_DIM):
        """Aggiorna la barra di stato."""
        self._var_status.set(messaggio)
        self._dot_canvas.itemconfig(self._dot, fill=colore)

    def _mostra_stato_vuoto(self):
        """Mostra un messaggio neutro nell'area risultati quando è vuota."""
        for w in self._area_card.winfo_children():
            w.destroy()

        tk.Label(
            self._area_card,
            text="I risultati appariranno qui",
            font=FONT_STATUS,
            fg=TESTO_DIM,
            bg=SFONDO,
        ).pack(pady=60)

    # ─────────────────────────────────────────────────────────
    #  LOGICA UI: AVVIA, RESET, THREAD
    # ─────────────────────────────────────────────────────────

    def _avvia(self):
        """Legge i campi e avvia il processo in un thread separato."""
        testo   = self._leggi_campo(self.campo_testo)
        domanda = self._leggi_campo(self.campo_domanda)

        if not testo:
            self._set_status("Inserisci un testo prima di procedere.", ROSSO)
            return
        if not domanda:
            self._set_status("Inserisci una domanda prima di procedere.", ROSSO)
            return

        # Prepara UI per l'elaborazione
        self.btn_avvia.configure(state="disabled", bg=GIALLO_SC)
        self._mostra_stato_vuoto()
        self.progresso.reset()
        self._set_status("Elaborazione in corso...", GIALLO)
        self._var_tempo.set("")

        # Avvia il processo in background per non bloccare l'UI
        threading.Thread(
            target=self._thread_elaborazione,
            args=(testo, domanda),
            daemon=True
        ).start()

    def _thread_elaborazione(self, testo, domanda):
        """
        Gira in background:
        genera 5 risposte, valuta ognuna, poi mostra i risultati.
        """
        inizio = time.time()
        risultati = []           # lista di tuple (risposta, punteggio)
        risposte_precedenti = [] # usate per l'estensione facoltativa

        for i in range(NUM_RISPOSTE):

            # Aggiorna UI: segmento attivo
            self.after(0, lambda idx=i: (
                self._set_status(f"Generazione risposta {idx + 1} di {NUM_RISPOSTE}...", GIALLO),
                self.progresso.attiva(idx)
            ))

            # Genera risposta (con contesto delle precedenti se disponibile)
            contesto = risposte_precedenti if i > 0 else None
            risposta = genera_risposta(testo, domanda, contesto)

            # Gestione errore connessione
            if risposta is None:
                self.after(0, lambda idx=i: (
                    self.progresso.completa(idx, successo=False),
                    self._set_status("Errore: Ollama non raggiungibile.", ROSSO),
                    self.btn_avvia.configure(state="normal", bg=GIALLO)
                ))
                return

            # Valuta la risposta
            self.after(0, lambda idx=i:
                self._set_status(f"Valutazione risposta {idx + 1}...", GIALLO))

            punteggio = valuta_risposta(testo, domanda, risposta)

            risultati.append((risposta, punteggio))
            risposte_precedenti.append((risposta, punteggio))

            # Segna il segmento come completato
            self.after(0, lambda idx=i: self.progresso.completa(idx, successo=True))

        # Tutto completato → mostra risultati
        durata = time.time() - inizio
        self.after(0, lambda: self._mostra_risultati(risultati, durata))

    def _mostra_risultati(self, risultati, durata):
        """Popola il pannello destro con le card delle risposte."""
        for w in self._area_card.winfo_children():
            w.destroy()

        # Trova l'indice della risposta con punteggio più alto
        idx_migliore = max(range(len(risultati)), key=lambda i: risultati[i][1])

        # Crea le card — la migliore appare per prima
        ordine = [idx_migliore] + [i for i in range(len(risultati)) if i != idx_migliore]

        for posizione, idx in enumerate(ordine):
            risposta, punteggio = risultati[idx]
            card = CardRisposta(
                self._area_card,
                numero=idx + 1,
                testo=risposta,
                punteggio=punteggio,
                migliore=(idx == idx_migliore),
            )
            card.pack(fill="x", pady=(0, 10))

            # Separatore tra card
            tk.Frame(self._area_card, height=1, bg=BORDO).pack(fill="x", pady=(0, 6))

        self._canvas.yview_moveto(0)

        # Aggiorna status bar
        punteggio_migliore = risultati[idx_migliore][1]
        self._set_status(
            f"Completato — migliore: {punteggio_migliore}/10 · {NUM_RISPOSTE} risposte",
            VERDE
        )
        self._var_tempo.set(f"{durata:.1f}s")
        self.btn_avvia.configure(state="normal", bg=GIALLO)

    def _reset(self):
        """Pulisce tutti i campi e riporta l'app allo stato iniziale."""
        # Ripristina campo testo
        self.campo_testo.configure(fg=TESTO_DIM)
        self.campo_testo.delete("1.0", "end")
        self.campo_testo.insert("1.0", self.campo_testo._placeholder)

        # Ripristina campo domanda
        self.campo_domanda.configure(fg=TESTO_DIM)
        self.campo_domanda.delete("1.0", "end")
        self.campo_domanda.insert("1.0", self.campo_domanda._placeholder)

        self._mostra_stato_vuoto()
        self.progresso.reset()
        self._set_status("Pronto", TESTO_DIM)
        self._var_tempo.set("")
        self.btn_avvia.configure(state="normal", bg=GIALLO)


# =============================================================
#  AVVIO
# =============================================================

if __name__ == "__main__":
    app = App()
    app.mainloop()
