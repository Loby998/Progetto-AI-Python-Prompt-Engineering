# =============================================================
#  validatore_risposte.py  —  Logica backend
# =============================================================

import requests
from concurrent.futures import ThreadPoolExecutor, as_completed

# ── CONFIGURAZIONE ───────────────────────────────────────────

URL     = "http://localhost:11434/api/chat"
MODELLO = "qwen2.5:1.5b-instruct"

# Prompt migliorati per forzare l'aderenza al testo
SYSTEM_RISPOSTA = (
    "Sei un assistente esperto nell'analisi di testi. "
    "Riceverai un testo e una domanda. "
    "Devi rispondere alla domanda usando ESCLUSIVAMENTE le informazioni presenti nel testo fornito. "
    "Se la risposta non è nel testo, scrivi 'Informazione non presente nel testo'. "
    "Sii sintetico, chiaro e vai dritto al punto."
)

SYSTEM_GIUDICE = (
    "Sei un valutatore severo e preciso. Valuta la risposta in base a quanto è fedele al testo originale. "
    "Assegna un punteggio da 1 a 10:\n"
    "- 9-10: Perfetta, basata solo sul testo.\n"
    "- 7-8: Corretta ma incompleta.\n"
    "- 5-6: Parziale o con imprecisioni.\n"
    "- 1-4: Fuori tema, inventata o errata.\n"
    "Rispondi SOLO con il numero intero (es. 8). Nessuna parola aggiuntiva."
)

# ── FUNZIONI BASE ─────────────────────────────────────────────

def chiama_modello(system_prompt, messaggio_utente):
    payload = {
        "model": MODELLO,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user",   "content": messaggio_utente},
        ],
        "stream": False,
        "options": {
            "temperature": 0.1,  # ABBASSA LA CREATIVITÀ: Meno deliri, più precisione
            "top_p": 0.9
        }
    }

    try:
        risposta = requests.post(URL, json=payload, timeout=90)
        risposta.raise_for_status()
        return risposta.json()["message"]["content"].strip()
    except Exception as e:
        print(f"Errore chiamata modello: {e}")
        return None

def genera_risposta(testo, domanda):
    messaggio = f"TESTO:\n{testo}\n\nDOMANDA:\n{domanda}\n\nRispondi basandoti solo sul testo."
    return chiama_modello(SYSTEM_RISPOSTA, messaggio)

def valuta_risposta(testo, domanda, risposta):
    messaggio = (
        f"TESTO ORIGINALE:\n{testo}\n\n"
        f"DOMANDA:\n{domanda}\n\n"
        f"RISPOSTA:\n{risposta}\n\n"
        f"Dai un punteggio da 1 a 10. SOLO il numero."
    )
    risultato = chiama_modello(SYSTEM_GIUDICE, messaggio)
    
    if risultato is None: return 0
    
    for parola in risultato.split():
        parola_pulita = parola.strip(".,!?:/\n")
        if parola_pulita.isdigit():
            return max(1, min(10, int(parola_pulita)))
    return 5

# ── ESECUZIONE PARALLELA ──────────────────────────────────────

def genera_e_valuta_parallelo(testo, domanda, n, callback=None):
    """Genera e valuta N risposte contemporaneamente."""
    risultati = {}

    def elabora_singola(idx):
        risposta = genera_risposta(testo, domanda)
        if risposta is None:
            return idx, "Errore di connessione a Ollama", 0
        punteggio = valuta_risposta(testo, domanda, risposta)
        return idx, risposta, punteggio

    with ThreadPoolExecutor(max_workers=min(n, 10)) as executor:
        futures = [executor.submit(elabora_singola, i) for i in range(n)]

        for future in as_completed(futures):
            idx, risposta, punteggio = future.result()
            risultati[idx] = (risposta, punteggio)
            if callback:
                callback(idx, risposta, punteggio) # Aggiorna la UI

    return [risultati[i] for i in range(n) if i in risultati]