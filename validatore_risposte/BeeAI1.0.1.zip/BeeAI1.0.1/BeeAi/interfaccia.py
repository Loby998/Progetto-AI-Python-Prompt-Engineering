# =============================================================
#  interfaccia.py  —  Interfaccia grafica Validatore AI (CustomTkinter)
# =============================================================

import customtkinter as ctk
import threading
import time

from validatore_risposte import genera_e_valuta_parallelo, MODELLO

# ── CONFIGURAZIONE TEMA ─────────────────────────────────────
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

GIALLO = "#FFD600"
GIALLO_HOVER = "#CC9900"
SFONDO_CARD = "#1A1A1A"
VERDE = "#22c55e"
ROSSO = "#ef4444"

class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Validatore AI - Pro")
        self.geometry("1100x750")
        self.minsize(900, 600)

        self.costruisci_interfaccia()

    def costruisci_interfaccia(self):
        # ── HEADER ──
        self.header_frame = ctk.CTkFrame(self, fg_color="transparent")
        self.header_frame.pack(fill="x", padx=30, pady=(20, 10))

        ctk.CTkLabel(self.header_frame, text="Validatore AI", font=("Segoe UI", 24, "bold")).pack(side="left")
        ctk.CTkLabel(self.header_frame, text=MODELLO, text_color="gray").pack(side="left", padx=15, pady=(8,0))

        # Progress bar in alto a destra
        self.progressbar = ctk.CTkProgressBar(self.header_frame, width=200, height=10, progress_color=GIALLO)
        self.progressbar.pack(side="right", pady=(10, 0))
        self.progressbar.set(0) # Inizia vuota
        
        self.lbl_progresso = ctk.CTkLabel(self.header_frame, text="0%", font=("Segoe UI", 12))
        self.lbl_progresso.pack(side="right", padx=10, pady=(4, 0))

        # Linea separatrice
        ctk.CTkFrame(self, height=2, fg_color=GIALLO).pack(fill="x", padx=30)

        # ── CORPO PRINCIPALE ──
        self.main_frame = ctk.CTkFrame(self, fg_color="transparent")
        self.main_frame.pack(fill="both", expand=True, padx=30, pady=20)

        # PANNELLO SINISTRO (Input)
        self.left_panel = ctk.CTkFrame(self.main_frame, width=350, fg_color="transparent")
        self.left_panel.pack(side="left", fill="y")
        self.left_panel.pack_propagate(False)

        ctk.CTkLabel(self.left_panel, text="TESTO DI RIFERIMENTO", font=("Segoe UI", 12, "bold")).pack(anchor="w")
        self.txt_testo = ctk.CTkTextbox(self.left_panel, height=250, corner_radius=10)
        self.txt_testo.pack(fill="x", pady=(5, 20))

        ctk.CTkLabel(self.left_panel, text="DOMANDA", font=("Segoe UI", 12, "bold")).pack(anchor="w")
        self.txt_domanda = ctk.CTkTextbox(self.left_panel, height=80, corner_radius=10)
        self.txt_domanda.pack(fill="x", pady=(5, 20))

        # Contenitore per menù a tendina e bottoni
        self.controls_frame = ctk.CTkFrame(self.left_panel, fg_color="transparent")
        self.controls_frame.pack(fill="x")

        ctk.CTkLabel(self.controls_frame, text="Numero di risposte:").pack(side="left")
        self.combo_num = ctk.CTkComboBox(self.controls_frame, values=["1", "2", "3", "5", "10"], width=80)
        self.combo_num.set("3")
        self.combo_num.pack(side="right")

        self.btn_avvia = ctk.CTkButton(self.left_panel, text="AVVIA ANALISI", font=("Segoe UI", 14, "bold"),
                                       fg_color=GIALLO, text_color="black", hover_color=GIALLO_HOVER,
                                       height=45, corner_radius=10, command=self.avvia_elaborazione)
        self.btn_avvia.pack(fill="x", pady=(25, 10))

        self.btn_reset = ctk.CTkButton(self.left_panel, text="Reset", fg_color="transparent", 
                                       border_width=1, text_color="gray", hover_color="#333333",
                                       command=self.reset_ui)
        self.btn_reset.pack(fill="x")

        # Separatore verticale
        ctk.CTkFrame(self.main_frame, width=2, fg_color="#333333").pack(side="left", fill="y", padx=20)

        # PANNELLO DESTRO (Risultati Scrollabili)
        self.scrollable_results = ctk.CTkScrollableFrame(self.main_frame, fg_color="transparent")
        self.scrollable_results.pack(side="left", fill="both", expand=True)
        
        self.lbl_stato = ctk.CTkLabel(self.scrollable_results, text="I risultati appariranno qui...", text_color="gray")
        self.lbl_stato.pack(pady=100)

    # ── LOGICA DI ESECUZIONE (THREADING) ──
    def avvia_elaborazione(self):
        testo = self.txt_testo.get("1.0", "end-1c").strip()
        domanda = self.txt_domanda.get("1.0", "end-1c").strip()
        num_risposte = int(self.combo_num.get())

        if not testo or not domanda:
            return

        # Preparazione UI
        self.btn_avvia.configure(state="disabled", text="Elaborazione...")
        for widget in self.scrollable_results.winfo_children():
            widget.destroy()
        
        self.progressbar.set(0)
        self.lbl_progresso.configure(text="0%")
        self.risposte_completate = 0

        # Avvia in background per non bloccare l'interfaccia
        threading.Thread(target=self.thread_elaborazione, args=(testo, domanda, num_risposte), daemon=True).start()

    def thread_elaborazione(self, testo, domanda, num_risposte):
        start_time = time.time()

        # Funzione di callback chiamata ogni volta che una risposta singola è pronta
        def aggiorna_progresso(idx, risposta, punteggio):
            self.risposte_completate += 1
            percentuale = self.risposte_completate / num_risposte
            
            # Aggiorna la UI in modo sicuro dai thread
            self.after(0, lambda: self.progressbar.set(percentuale))
            self.after(0, lambda: self.lbl_progresso.configure(text=f"{int(percentuale*100)}%"))

        # Esegue tutto in parallelo
        risultati = genera_e_valuta_parallelo(testo, domanda, num_risposte, callback=aggiorna_progresso)
        
        durata = time.time() - start_time
        
        # Mostra i risultati finali sulla UI
        self.after(0, lambda: self.mostra_risultati(risultati, durata))

    def mostra_risultati(self, risultati, durata):
        self.btn_avvia.configure(state="normal", text="AVVIA ANALISI")
        self.lbl_progresso.configure(text=f"Fatto in {durata:.1f}s")

        # Trova l'indice della migliore
        idx_migliore = max(range(len(risultati)), key=lambda i: risultati[i][1])
        ordine = [idx_migliore] + [i for i in range(len(risultati)) if i != idx_migliore]

        for _, idx in enumerate(ordine):
            risposta, punteggio = risultati[idx]
            migliore = (idx == idx_migliore)
            
            self.crea_card_risposta(idx + 1, risposta, punteggio, migliore)

    def crea_card_risposta(self, numero, testo, punteggio, migliore):
        colore_bordo = GIALLO if migliore else "#333333"
        colore_punteggio = VERDE if punteggio >= 7 else (GIALLO if punteggio >= 4 else ROSSO)

        card = ctk.CTkFrame(self.scrollable_results, fg_color=SFONDO_CARD, border_width=2, border_color=colore_bordo, corner_radius=10)
        card.pack(fill="x", pady=(0, 15), padx=5)

        header = ctk.CTkFrame(card, fg_color="transparent")
        header.pack(fill="x", padx=15, pady=(10, 5))

        etichetta = "⭐ MIGLIORE RISPOSTA" if migliore else f"Risposta {numero}"
        ctk.CTkLabel(header, text=etichetta, font=("Segoe UI", 12, "bold"), text_color=colore_bordo).pack(side="left")
        
        ctk.CTkLabel(header, text=f"{punteggio}/10", font=("Segoe UI", 16, "bold"), text_color=colore_punteggio).pack(side="right")

        txt_box = ctk.CTkTextbox(card, height=80, fg_color="transparent", text_color="white", wrap="word")
        txt_box.pack(fill="x", padx=10, pady=(0, 10))
        txt_box.insert("1.0", testo)
        txt_box.configure(state="disabled")

    def reset_ui(self):
        self.txt_testo.delete("1.0", "end")
        self.txt_domanda.delete("1.0", "end")
        self.progressbar.set(0)
        self.lbl_progresso.configure(text="0%")
        for widget in self.scrollable_results.winfo_children():
            widget.destroy()
        self.lbl_stato = ctk.CTkLabel(self.scrollable_results, text="I risultati appariranno qui...", text_color="gray")
        self.lbl_stato.pack(pady=100)

if __name__ == "__main__":
    app = App()
    app.mainloop()